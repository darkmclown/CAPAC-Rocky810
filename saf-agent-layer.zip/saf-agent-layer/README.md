# SAF agent layer

An add-on that makes a solution built with the Solution Application Framework (SAF) ready for agent-driven development. SAF stays the host and is never modified. The layer adds knowledge, tasks, run logs, skills and git rules on top of any solution created with `saf new`.

This is an unofficial kit. It is not affiliated with or endorsed by Ansys.

## What each side provides

| SAF provides | The layer adds |
|---|---|
| Solution structure, GLOW backend, UI, tests | `agent/`: knowledge, decisions, tasks, run summaries, skills |
| `saf` CLI: install, run, add-step, build, archive | `justfile`: one command surface that wraps `saf` and the layer |
| `AGENTS.md` with SAF guidance | A managed "Agent layer" section in the same file |
| MCP server for driving a running solution | A drafted `SOLUTION.md` and a `verify-with-mcp` skill |
| pre-commit style hooks | Secret scanning, validation and commit-message hooks |
| Build and release workflows | An `Agent layer` workflow for pull requests |

## Requirements

- Python 3.9 or newer and git. The tooling uses only the standard library.
- `just`, recommended. Without it, call `python agent/tools/agentkit.py <command>`.
- The SAF CLI, for the recipes that wrap `saf`.

## Install

```bash
saf new                                   # create the solution as usual
python install.py path/to/my_solution     # apply the layer
cd path/to/my_solution
just hooks                                # git hooks through pre-commit (SAF's way)
# or: just hooks-native                   # plain git hooks, no pre-commit needed
git add -A
git commit -m "chore: add agent layer"
```

For team projects, add `--use-template` to start `AGENTS.md` from the team template (project facts, SAF essentials, agent-layer section), then fill in the placeholders. The template is used automatically when a project has no `AGENTS.md`.

Running the installer again updates the tooling and the standard. It leaves your skills, templates, knowledge files and settings alone unless you pass `--force`.

## What the installer changes

| File | Change |
|---|---|
| `agent/` | Created: standard, skills, templates, tooling, empty knowledge and task folders |
| `agent/knowledge/entities/` | One draft per step, UI page and the solution, read from your source code |
| `SOLUTION.md` beside `definition.py` | Drafted if missing, for SAF's MCP server |
| `justfile` | Created. If you already have one, `justfile.agent-layer` is written for you to merge |
| `local.manifest.jsonl` | Created empty |
| `AGENTS.md` | SAF's text is kept; a managed section is added between markers |
| `.gitignore` | A managed block that ignores `local/` |
| `.pre-commit-config.yaml` | A managed block: Gitleaks, validation, commit-message check |
| `.github/workflows/agent-layer.yml` | Created |
| `.github/pull_request_template.md` | Created if missing |

No solution code is changed.

## Daily workflow

```bash
just task-new "Add CSV export"          # a human or an agent writes the task
just task-claim T-0001 --agent builder  # branch feature/T-0001-add-csv-export, pushed
just find export                        # locate the right files through the index
# ... work, with commits like:  feat: add CSV export [T-0001]
just check                              # tests, style, validation
just task-done T-0001                   # closes the run, moves the task, commits
git push                                # then open a pull request
```

Run `just --list` for every command. `agent/standard.md` is the full reference.

## Git integration

| Part | What it does |
|---|---|
| Local hooks | Before each commit: validation, plus Gitleaks secret scanning when installed through pre-commit. On the message: conventional commit type, and the task ID when you are on a task branch |
| GitHub Actions | On each pull request: validation, branch name and commit messages. SAF's own workflows keep running the tests |
| Task workflow | A claim creates the task branch on the remote, so two agents cannot take the same task. The pull request template asks for the task, the run summary and anything that needs human approval |

## Where SAF and the earlier standard disagreed

| Topic | Resolution |
|---|---|
| `.env` is tracked by SAF | Secrets go in `local/secrets.env`. `just run` merges both into `local/run.env`. Validation fails if `.env` holds a secret |
| SAF owns the environment | `.venv/` and `.poetry/` stay where `saf install` puts them |
| SAF uses `doc/` for Sphinx | Agent files live under `agent/`, so nothing collides |
| SAF branch types | Kept, with the task ID added: `feature/T-0042-short-name` |
| `saf archive` packs the whole folder | `just archive-clean <file>` removes `local/` and `legacy/` from the archive |

## Tested and not tested

Tested here, against SAF's real solution template rendered at commit `247a767` (21 November 2026):

- installer on the Dash and the no-UI variants, twice each;
- every `agentkit` command, the native git hooks, and the two-agent claim race against a local remote;
- 12 automated tests: `python -m unittest discover -s tests -v`.

Not run here, because the tools were not available in the build environment:

- the `saf` commands themselves and the recipes that call them;
- the `justfile` under `just`;
- the pre-commit block under the pre-commit framework, and the GitHub Actions workflow on GitHub. Both files were checked to be valid YAML.

Try those four on a real solution before relying on them.

## Removing the layer

Delete `agent/`, `local/`, `local.manifest.jsonl`, `justfile` and `.github/workflows/agent-layer.yml`, and remove the blocks between the `agent-layer` markers in `AGENTS.md`, `.gitignore` and `.pre-commit-config.yaml`.

## Documents

| File | What it is |
|---|---|
| `docs/PLATFORM.md` | The platform for the whole team: architecture, default tools, folder structure, workflows, migration plan |
| `docs/AGENTS.template.md` | The `AGENTS.md` template with the managed section filled in |
| `layer/agent/standard.md` | The detailed rules installed into each project |

## Notes

- The Gitleaks revision and the `actions/checkout` pin are the ones SAF's own configuration uses.
- The SAF coding rules in the standard and the skills are summarised from SAF's best-practice guides. Read the guides for the details.
