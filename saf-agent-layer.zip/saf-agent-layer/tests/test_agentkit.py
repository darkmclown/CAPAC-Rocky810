"""Tests for the agent layer. Run with:  python -m unittest discover -s tests -v

They build a small SAF-shaped solution in a temporary folder, apply the layer and
exercise the tooling against a real git repository with a local remote.
Only git and the Python standard library are needed; SAF itself is not.
"""
from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

KIT = Path(__file__).resolve().parents[1]
STEP = '''"""Backend of the first step."""
from ansys.saf.glow.solution import StepModel, StepSpec, transaction


class FirstStep(StepModel):
    """Adds two numbers."""

    first_arg: float = 0
    result: float = 0

    @transaction(self=StepSpec(upload=["result"], download=["first_arg"]))
    def calculate(self) -> None:
        """Compute the result."""
        self.result = self.first_arg
'''
DEFINITION = '''"""Solution definition module."""
from ansys.saf.glow.solution import Solution, StepsModel


class Steps(StepsModel):
    first_step: FirstStep


class Demo(Solution):
    display_name: str = "Demo"
    steps: Steps
'''


def run(cmd: list[str], cwd: Path, check: bool = True) -> subprocess.CompletedProcess:
    result = subprocess.run(cmd, cwd=cwd, text=True, capture_output=True)
    if check and result.returncode != 0:
        raise AssertionError(f"{' '.join(cmd)} failed:\n{result.stdout}\n{result.stderr}")
    return result


def load_agentkit():
    spec = importlib.util.spec_from_file_location("agentkit", KIT / "layer" / "agent" / "tools" / "agentkit.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.CFG = json.loads(json.dumps(module.DEFAULTS))
    return module


class LayerTest(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        base = Path(self.tmp.name)
        self.remote = base / "remote.git"
        run(["git", "init", "-q", "--bare", "-b", "main", str(self.remote)], base)
        self.sol = self.make_clone(base / "demo", create=True)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def make_clone(self, path: Path, create: bool = False) -> Path:
        if create:
            source = path / "src" / "saf" / "solutions" / "demo" / "solution"
            source.mkdir(parents=True)
            (source / "first_step.py").write_text(STEP)
            (source / "definition.py").write_text(DEFINITION)
            (path / ".env").write_text("GLOW_SOLUTION_DEFINITION=saf.solutions.demo.solution.definition\n")
            (path / "pyproject.toml").write_text('[tool.poetry.dependencies]\nansys-saf-sdk = ">=0.4.0"\n')
            (path / "AGENTS.md").write_text("# AGENTS guidelines for this repository\n\nSAF text.\n")
            (path / ".pre-commit-config.yaml").write_text("repos:\n  - repo: https://example.com/x\n    rev: v1\n    hooks:\n      - id: x\n")
            run(["git", "init", "-q", "-b", "main"], path)
            run(["git", "remote", "add", "origin", str(self.remote)], path)
        else:
            run(["git", "clone", "-q", "-b", "main", str(self.remote), str(path)], path.parent)
        run(["git", "config", "user.email", "t@example.com"], path)
        run(["git", "config", "user.name", "T"], path)
        if create:
            run([sys.executable, str(KIT / "install.py"), str(path)], path)
            config = path / "agent" / "config.json"
            data = json.loads(config.read_text())
            data["check_command"] = [sys.executable, "-c", "print('ok')"]
            config.write_text(json.dumps(data))
            run(["git", "add", "-A"], path)
            run(["git", "commit", "-q", "-m", "chore: add solution and agent layer"], path)
            run(["git", "push", "-q", "-u", "origin", "main"], path)
        return path

    def kit(self, *args: str, cwd: Path | None = None, check: bool = True) -> subprocess.CompletedProcess:
        cwd = cwd or self.sol
        return run([sys.executable, "agent/tools/agentkit.py", *args], cwd, check)

    def new_task(self, title: str = "Add export") -> None:
        self.kit("task-new", title)
        run(["git", "add", "-A"], self.sol)
        run(["git", "commit", "-q", "-m", "chore: add task"], self.sol)
        run(["git", "push", "-q", "origin", "main"], self.sol)

    # ------------------------------------------------------------------ installer
    def test_install_detects_solution_and_drafts_knowledge(self) -> None:
        config = json.loads((self.sol / "agent" / "config.json").read_text())
        self.assertEqual(config["solution_name"], "demo")
        self.assertEqual(config["source_root"], "src/saf/solutions/demo")
        entity = (self.sol / "agent" / "knowledge" / "entities" / "step-first-step.md").read_text()
        self.assertIn("`calculate`", entity)
        self.assertIn("last_verified: null", entity)
        self.assertTrue((self.sol / "src/saf/solutions/demo/solution/SOLUTION.md").is_file())
        self.assertIn("agent-layer:start", (self.sol / "AGENTS.md").read_text())
        self.assertIn("SAF text.", (self.sol / "AGENTS.md").read_text())
        self.assertIn("/local/", (self.sol / ".gitignore").read_text())
        precommit = (self.sol / ".pre-commit-config.yaml").read_text()
        self.assertIn("https://example.com/x", precommit)
        self.assertIn("agent-layer-validate", precommit)
        self.assertEqual(self.kit("validate").returncode, 0)

    def test_install_is_idempotent(self) -> None:
        before = {p: p.read_bytes() for p in self.sol.rglob("*") if p.is_file() and ".git" not in p.parts and "local" not in p.parts}
        run([sys.executable, str(KIT / "install.py"), str(self.sol)], self.sol)
        after = {p: p.read_bytes() for p in self.sol.rglob("*") if p.is_file() and ".git" not in p.parts and "local" not in p.parts}
        changed = [str(p) for p in after if before.get(p) != after[p] and p.name != "config.json"]
        self.assertEqual(changed, [])

    def test_install_refuses_non_saf_folder(self) -> None:
        plain = Path(self.tmp.name) / "plain"
        plain.mkdir()
        result = run([sys.executable, str(KIT / "install.py"), str(plain)], plain, check=False)
        self.assertNotEqual(result.returncode, 0)

    def test_team_template_for_agents_md(self) -> None:
        agents = self.sol / "AGENTS.md"
        self.assertNotIn("## Project facts", agents.read_text())  # SAF's own file was kept
        run([sys.executable, str(KIT / "install.py"), str(self.sol), "--use-template"], self.sol)
        text = agents.read_text()
        self.assertIn("## Project facts", text)
        self.assertIn("| Solution name | `demo` |", text)
        self.assertIn("src/saf/solutions/demo/solution/definition.py", text)
        self.assertIn("agent-layer:start", text)
        self.assertIn("`start-task`", text)
        self.assertNotIn("__SOLUTION__", text)
        self.assertLessEqual(len(text.splitlines()), 250)
        result = self.kit("validate")
        self.assertEqual(result.returncode, 0)
        self.assertIn("placeholders to fill in", result.stdout)
        agents.unlink()  # a project without AGENTS.md gets the template automatically
        run([sys.executable, str(KIT / "install.py"), str(self.sol)], self.sol)
        self.assertIn("## Project facts", agents.read_text())

    # ------------------------------------------------------------------ pure functions
    def test_frontmatter_round_trip(self) -> None:
        kit = load_agentkit()
        path = Path(self.tmp.name) / "x.md"
        path.write_text("---\nid: T-0001\ntitle: \"A: b\"\nstatus: backlog   # note\nruns: []\ndone_at: null\n---\n## Body\n")
        kit.ROOT = Path(self.tmp.name)
        data, body = kit.read_fm(path)
        self.assertEqual(data, {"id": "T-0001", "title": "A: b", "status": "backlog", "runs": [], "done_at": None})
        kit.set_fm(path, status="done", runs=["r1", "r2"], extra="x")
        data, body = kit.read_fm(path)
        self.assertEqual((data["status"], data["runs"], data["extra"], data["title"]), ("done", ["r1", "r2"], "x", "A: b"))
        self.assertEqual(body, "## Body\n")

    def test_commit_message_rules(self) -> None:
        kit = load_agentkit()
        self.assertIsNone(kit.commit_problem("feat: add export [T-0042]", "feature/T-0042-add-export"))
        self.assertIsNone(kit.commit_problem("chore: tidy", "main"))
        self.assertIsNone(kit.commit_problem("Merge branch 'main' into x", "feature/T-0042-add-export"))
        self.assertIsNotNone(kit.commit_problem("added export", "main"))
        self.assertIsNotNone(kit.commit_problem("feat: add export", "feature/T-0042-add-export"))
        self.assertIsNotNone(kit.commit_problem("feat: add export [T-0001]", "feature/T-0042-add-export"))

    def test_branch_rules(self) -> None:
        kit = load_agentkit()
        for good in ["main", "feature/T-0042-add-export", "bugfix/T-0001-x", "chore/pre-commit-autoupdate"]:
            self.assertIsNone(kit.branch_problem(good), good)
        for bad in ["feature/add-export", "task/T-0042-x", "feature/T-42-x"]:
            self.assertIsNotNone(kit.branch_problem(bad), bad)

    # ------------------------------------------------------------------ workflow
    def test_task_lifecycle(self) -> None:
        self.new_task()
        self.kit("task-claim", "T-0001", "--agent", "builder")
        branch = run(["git", "rev-parse", "--abbrev-ref", "HEAD"], self.sol).stdout.strip()
        self.assertEqual(branch, "feature/T-0001-add-export")
        self.assertIn(branch, run(["git", "ls-remote", "--heads", "origin"], self.sol).stdout)
        self.kit("log", "tool_call", "--tool", "pytest", "--duration-ms", "12")
        events = list((self.sol / "local" / "logs").glob("*/*.jsonl"))[0].read_text().splitlines()
        self.assertEqual([json.loads(line)["event"] for line in events], ["run_start", "tool_call"])
        self.assertNotEqual(self.kit("task-done", "T-0001", check=False).returncode, 0)  # summary is empty
        summary = next((self.sol / "agent" / "logs").glob("*/*.md"))
        summary.write_text(summary.read_text().replace("## What changed\n", "## What changed\n\nAdded export.\n"))
        self.kit("task-done", "T-0001")
        self.assertTrue((self.sol / "agent/tasks/done/T-0001-add-export.md").is_file())
        self.assertIn("status: success", summary.read_text())
        self.assertFalse((self.sol / "local/run/current.json").exists())
        self.assertEqual(run(["git", "status", "--porcelain"], self.sol).stdout.strip(), "")
        self.assertEqual(self.kit("check-commits", "main..HEAD", "--branch", branch).returncode, 0)

    def test_second_agent_cannot_claim_the_same_task(self) -> None:
        self.new_task()
        other = self.make_clone(Path(self.tmp.name) / "other")
        self.kit("task-claim", "T-0001", "--agent", "a")
        refused = self.kit("task-claim", "T-0001", "--agent", "b", cwd=other, check=False)
        self.assertNotEqual(refused.returncode, 0)
        raced = self.kit("task-claim", "T-0001", "--agent", "b", "--skip-remote-check", cwd=other, check=False)
        self.assertNotEqual(raced.returncode, 0)
        self.assertEqual(run(["git", "rev-parse", "--abbrev-ref", "HEAD"], other).stdout.strip(), "main")
        self.assertEqual(run(["git", "status", "--porcelain"], other).stdout.strip(), "")
        self.assertTrue((other / "agent/tasks/backlog/T-0001-add-export.md").is_file())

    def test_drift_blocks_task_done(self) -> None:
        self.new_task()
        self.kit("task-claim", "T-0001")
        step = self.sol / "src/saf/solutions/demo/solution/first_step.py"
        step.write_text(step.read_text() + "\n    @transaction(self=StepSpec())\n    def reset(self) -> None:\n        self.result = 0\n")
        self.assertIn("`reset`", self.kit("scan", "--report").stdout)
        summary = next((self.sol / "agent" / "logs").glob("*/*.md"))
        summary.write_text(summary.read_text().replace("## What changed\n", "## What changed\n\nAdded reset.\n"))
        run(["git", "add", "-A"], self.sol)
        run(["git", "commit", "-q", "-m", "feat: add reset [T-0001]"], self.sol)
        blocked = self.kit("task-done", "T-0001", check=False)
        self.assertNotEqual(blocked.returncode, 0)
        self.assertIn("drift", blocked.stdout)

    # ------------------------------------------------------------------ validation
    def test_validate_catches_problems(self) -> None:
        cases = {
            "secret": lambda: (self.sol / ".env").write_text((self.sol / ".env").read_text() + "API_TOKEN=abc\n"),
            "manifest": lambda: (self.sol / "local/data/big.bin").write_bytes(b"x" * 10),
            "broken link": lambda: (self.sol / "agent/architecture/a.md").write_text("# A\n\n[x](missing.md)\n"),
            "limit": lambda: (self.sol / "agent/knowledge/entities/step-first-step.md").write_text(
                (self.sol / "agent/knowledge/entities/step-first-step.md").read_text() + "line\n" * 120),
            "unknown entity": lambda: (self.sol / "agent/knowledge/entities/x.md").write_text(
                "---\nid: x\ntype: data\nstatus: active\npaths: []\ndepends_on: [nope]\nupdated_at: n\nlast_verified: null\n---\n# X\n"),
        }
        for name, break_it in cases.items():
            with self.subTest(name):
                run(["git", "stash", "-q", "--include-untracked"], self.sol, check=False)
                run(["git", "checkout", "-q", "."], self.sol)
                run(["git", "clean", "-qfd", "agent", "local/data"], self.sol)
                (self.sol / "local/data").mkdir(parents=True, exist_ok=True)
                for leftover in (self.sol / "local/data").glob("*"):
                    leftover.unlink()
                self.assertEqual(self.kit("validate", check=False).returncode, 0, "baseline must be clean")
                break_it()
                self.assertNotEqual(self.kit("validate", check=False).returncode, 0)

    def test_manifest_and_archive_clean(self) -> None:
        data = self.sol / "local/data/orders.bin"
        data.write_bytes(b"x" * 64)
        self.kit("manifest-add", "local/data/orders.bin", "--source", "backup")
        row = json.loads((self.sol / "local.manifest.jsonl").read_text().splitlines()[0])
        self.assertEqual((row["path"], row["kind"], row["size"], row["source"]), ("local/data/orders.bin", "data", 64, "backup"))
        self.assertEqual(self.kit("validate", "--full").returncode, 0)
        archive = Path(self.tmp.name) / "demo.saf"
        with zipfile.ZipFile(archive, "w") as handle:
            for name in ["src/a.py", "local/secrets.env", "local/data/orders.bin", "legacy/old.py", "agent/standard.md"]:
                handle.writestr(name, "x")
        self.kit("archive-clean", str(archive))
        self.assertEqual(sorted(zipfile.ZipFile(archive).namelist()), ["agent/standard.md", "src/a.py"])


if __name__ == "__main__":
    unittest.main()
