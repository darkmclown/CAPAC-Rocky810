# AGENTS guide: [fill in: project name]

<!--
TEMPLATE. Before agents use this file:
1. Replace every [fill in: ...] placeholder in "Project facts" and "Project notes".
2. Delete this comment.
3. Keep the file under 250 lines. Long explanations belong in agent/architecture/.
The section between the agent-layer markers is managed by the installer. Do not edit it by hand.
-->

Read this whole file at the start of every run. It is the map of the project.

## Project facts

| Fact | Value |
|---|---|
| What it does | [fill in: one sentence a new engineer would understand] |
| Who uses it | [fill in: roles or teams] |
| Status | [fill in: active / migrating from legacy / maintenance only] |
| Owner | [fill in: person who approves risky work] |
| Solution name | `__SOLUTION__` |
| Source folder | `__SOURCE_ROOT__/` |
| User interface | [fill in: Dash / none] |
| Ansys products used | [fill in: for example Mechanical, Fluent, MAPDL, or none] |
| Deployment | [fill in: desktop / on-premises / cloud] |
| Legacy code | [fill in: none, or in legacy/ and being ported feature by feature] |

### Flows that must never break

1. [fill in: the most important thing a user does with this solution]
2. [fill in: the second most important]

Run the tests for these flows before and after every change that touches them.

## SAF essentials

This project is a SAF solution. SAF hosts the application; do application work through the `saf` CLI, which the `just` recipes wrap.

| Part | Where | What it holds |
|---|---|---|
| Solution definition | `__SOURCE_ROOT__/solution/definition.py` | The steps of the workflow |
| Steps | `__SOURCE_ROOT__/solution/*.py` | One `StepModel` class per step: fields and `@transaction` methods |
| MCP guidance | `__SOURCE_ROOT__/solution/SOLUTION.md` | How to drive the running solution |
| User interface | `__SOURCE_ROOT__/ui/` | `app.py`, `pages/`, `assets/` |
| Tests | `tests/` | pytest tests using SAF's fixtures |
| User documentation | `doc/` | Sphinx sources |
| Deployment recipes | `deployments/` | Docker Compose files |

| Task | Command |
|---|---|
| Install or repair the environment | `just setup` |
| Run the tests | `just test` |
| Run the solution | `just run`, `just run --browser`, `just run-api` |
| Add a step from a template | `just add-step <name> <template>` |
| Run any command in the solution environment | `saf execute __SOLUTION__ "<command>"` |
| Add a dependency | `saf execute __SOLUTION__ "poetry add <package>"` |
| See a command's options | `saf <command> --help` |

Code follows PEP 8 with 120-character lines, type hints on public APIs and numpydoc docstrings. Add or update tests with every change in behaviour.

## Project notes

### Traps specific to this project

- [fill in: something that surprised the last person who worked here]

### External systems

- [fill in: system, what it is used for, and who to ask about it; or "none"]

<!-- agent-layer:start -->
(managed section: the installer fills this in)
<!-- agent-layer:end -->
