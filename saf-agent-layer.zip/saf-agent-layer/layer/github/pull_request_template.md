## Task

Task: `T-0000` (file in `agent/tasks/done/`)
Run summary: `agent/logs/<date>/<run-id>.md`

## What changed

## Checklist

- [ ] `just check` passes
- [ ] `just task-done <id>` succeeded, so validation passed and the task is in `agent/tasks/done/`
- [ ] Entity files and `SOLUTION.md` match the code I touched
- [ ] A decision record was added if the design changed
- [ ] Nothing from `local/` and no secret is in this pull request

## Needs human approval

List anything irreversible here: deploys, deletes, spending, data or project migrations. Write "none" if there is nothing.
