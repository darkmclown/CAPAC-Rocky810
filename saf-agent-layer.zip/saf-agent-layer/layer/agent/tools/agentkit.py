#!/usr/bin/env python3
"""agentkit: dependency-free tooling for the agent layer of a SAF solution.

Run from anywhere inside the solution:

    python agent/tools/agentkit.py <command> [options]

Only the Python standard library is used, so it works in any interpreter (3.9+).
"""
from __future__ import annotations

import argparse
import ast
import datetime as dt
import gzip
import hashlib
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

VERSION = "1.1.0"

DEFAULTS = {
    "solution_name": "",
    "source_root": "src",
    "base_branch": "main",
    "branch_types": ["feature", "bugfix", "hotfix", "refactor"],
    "exempt_branch_prefixes": ["chore/", "dependabot/", "release/"],
    "commit_types": ["feat", "fix", "docs", "chore", "refactor", "test"],
    "check_command": ["just", "check"],
    "log_retention_days": 30,
    "size_limits": {"agents_md": 250, "skill": 200, "entity": 100, "architecture": 200, "summary": 40},
    "entity_types": ["solution", "step", "ui-page", "component", "service", "product", "data", "config", "external"],
}
ENTITY_STATUS = ["active", "legacy", "deprecated"]
TASK_STATUS = ["backlog", "active", "done"]
DECISION_STATUS = ["proposed", "accepted", "superseded"]
RUN_STATUS = ["running", "success", "failed", "partial"]
LOG_FIELDS = ["ts", "run_id", "task_id", "agent", "event", "tool", "status", "duration_ms", "tokens", "error"]
MANIFEST_FIELDS = ["path", "kind", "size", "sha256", "source", "produced_by", "updated_at"]
MANIFEST_KINDS = ["data", "asset", "artifact"]
IRREPLACEABLE_DIRS = ["data", "assets", "artifacts"]
SECRET_KEY_RE = re.compile(r"(PASSWORD|PASSWD|SECRET|TOKEN|API_?KEY|PRIVATE_?KEY|CREDENTIAL)", re.I)
TASK_ID_RE = re.compile(r"T-\d{4}")
DECISION_ID_RE = re.compile(r"D-\d{4}")
ARCHIVE_DROP = ["local", "legacy"]

ROOT = Path.cwd()
CFG: dict = {}


# --------------------------------------------------------------------------- helpers
def die(message: str, code: int = 1) -> None:
    print(f"error: {message}", file=sys.stderr)
    sys.exit(code)


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def find_root(start: Path | None = None) -> Path:
    env = os.environ.get("AGENT_ROOT")
    here = Path(env).resolve() if env else (start or Path.cwd()).resolve()
    for candidate in [here, *here.parents]:
        if (candidate / "agent" / "config.json").is_file():
            return candidate
    die("no agent/config.json found here or in any parent folder. Run the installer first.")
    return here


def load_config(root: Path) -> dict:
    cfg = json.loads(json.dumps(DEFAULTS))
    user = json.loads((root / "agent" / "config.json").read_text(encoding="utf-8"))
    for key, value in user.items():
        if isinstance(value, dict) and isinstance(cfg.get(key), dict):
            cfg[key].update(value)
        else:
            cfg[key] = value
    return cfg


def rel(path: Path) -> str:
    return path.resolve().relative_to(ROOT.resolve()).as_posix()


def slugify(text: str, limit: int = 40) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return slug[:limit].strip("-") or "untitled"


def git(*args: str, check: bool = True) -> subprocess.CompletedProcess:
    result = subprocess.run(["git", *args], cwd=ROOT, text=True, capture_output=True)
    if check and result.returncode != 0:
        die(f"git {' '.join(args)} failed: {(result.stderr or result.stdout).strip()}")
    return result


def in_git() -> bool:
    return git("rev-parse", "--is-inside-work-tree", check=False).returncode == 0


def current_branch() -> str:
    return git("rev-parse", "--abbrev-ref", "HEAD", check=False).stdout.strip()


def has_remote() -> bool:
    return "origin" in git("remote", check=False).stdout.split()


# --------------------------------------------------------------------------- frontmatter
FM_RE = re.compile(r"\A---\r?\n(.*?)\r?\n---[ \t]*\r?\n?(.*)\Z", re.S)


def _strip_comment(value: str) -> str:
    out, quote = [], None
    for i, ch in enumerate(value):
        if quote:
            if ch == quote:
                quote = None
        elif ch in "\"'":
            quote = ch
        elif ch == "#" and (i == 0 or value[i - 1] in " \t"):
            break
        out.append(ch)
    return "".join(out).strip()


def _parse_scalar(value: str):
    value = value.strip()
    if value in ("", "null", "~"):
        return None
    if value in ("true", "false"):
        return value == "true"
    if value.startswith("[") and value.endswith("]"):
        inner = value[1:-1].strip()
        return [_parse_scalar(part) for part in inner.split(",")] if inner else []
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
        return json.loads(value) if value[0] == '"' else value[1:-1]
    if re.fullmatch(r"-?\d+", value):
        return int(value)
    return value


def _fmt_scalar(value) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, list):
        return "[" + ", ".join(_fmt_scalar(item) for item in value) + "]"
    text = str(value)
    risky = text == "" or text in ("null", "true", "false", "~") or text[0] in "[]{}&*!|>'\"%@`#-" or ": " in text
    return json.dumps(text) if risky or " #" in text or "," in text else text


def read_fm(path: Path) -> tuple[dict | None, str]:
    """Return (frontmatter, body). Frontmatter is None when the file has none."""
    text = path.read_text(encoding="utf-8")
    match = FM_RE.match(text)
    if not match:
        return None, text
    data = {}
    for line in match.group(1).splitlines():
        if not line.strip() or line.lstrip().startswith("#") or line[0] in " \t" or ":" not in line:
            continue
        key, value = line.split(":", 1)
        data[key.strip()] = _parse_scalar(_strip_comment(value))
    return data, match.group(2)


def set_fm(path: Path, **updates) -> None:
    """Update frontmatter keys in place, keeping every other line as it is."""
    text = path.read_text(encoding="utf-8")
    match = FM_RE.match(text)
    if not match:
        die(f"{rel(path)} has no frontmatter")
    lines, seen = [], set()
    for line in match.group(1).splitlines():
        key = line.split(":", 1)[0].strip() if ":" in line and line[:1] not in (" ", "\t", "#") else None
        if key in updates:
            lines.append(f"{key}: {_fmt_scalar(updates[key])}")
            seen.add(key)
        else:
            lines.append(line)
    for key, value in updates.items():
        if key not in seen:
            lines.append(f"{key}: {_fmt_scalar(value)}")
    path.write_text("---\n" + "\n".join(lines) + "\n---\n" + match.group(2), encoding="utf-8", newline="\n")


def render_template(name: str, **values) -> str:
    text = (ROOT / "agent" / "templates" / name).read_text(encoding="utf-8")
    for key, value in values.items():
        text = text.replace("{{" + key + "}}", str(value))
    return text


# --------------------------------------------------------------------------- paths
def tasks_dir(status: str) -> Path:
    return ROOT / "agent" / "tasks" / status


def find_task(task_id: str, status: str | None = None) -> Path | None:
    for folder in [status] if status else TASK_STATUS:
        for path in sorted(tasks_dir(folder).glob(f"{task_id}-*.md")):
            return path
    return None


def entity_files() -> list[Path]:
    return sorted((ROOT / "agent" / "knowledge" / "entities").glob("*.md"))


def next_id(prefix: str, folders: list[Path]) -> str:
    highest = 0
    for folder in folders:
        for path in folder.glob(f"{prefix}-*.md"):
            match = re.match(rf"{prefix}-(\d{{4}})", path.name)
            if match:
                highest = max(highest, int(match.group(1)))
    return f"{prefix}-{highest + 1:04d}"


# --------------------------------------------------------------------------- runs and logs
def run_pointer() -> Path:
    return ROOT / "local" / "run" / "current.json"


def current_run(required: bool = True) -> dict | None:
    if run_pointer().is_file():
        return json.loads(run_pointer().read_text(encoding="utf-8"))
    if required:
        die("no run is open. Start one with: task-claim <id> or run-start <id>")
    return None


def run_date(run_id: str) -> str:
    return f"{run_id[0:4]}-{run_id[4:6]}-{run_id[6:8]}"


def summary_path(run_id: str) -> Path:
    return ROOT / "agent" / "logs" / run_date(run_id) / f"{run_id}.md"


def events_path(run_id: str) -> Path:
    return ROOT / "local" / "logs" / run_date(run_id) / f"{run_id}.jsonl"


def write_event(run: dict, event: str, tool=None, status="ok", duration_ms=None, tokens=None, error=None, extra=None):
    record = {
        "ts": now(), "run_id": run["run_id"], "task_id": run["task_id"], "agent": run["agent"],
        "event": event, "tool": tool, "status": status, "duration_ms": duration_ms, "tokens": tokens, "error": error,
    }
    for key, value in (extra or {}).items():
        if key not in record:
            record[key] = value
    path = events_path(run["run_id"])
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(record, separators=(",", ":")) + "\n")


def start_run(task_id: str, agent: str) -> dict:
    if current_run(required=False):
        die(f"run {current_run()['run_id']} is still open. Close it with run-end or task-done first.")
    agent_slug = slugify(agent, 20)
    run_id = f"{dt.datetime.now(dt.timezone.utc):%Y%m%dT%H%M%SZ}-{agent_slug}-{secrets.token_hex(2)}"
    run = {"run_id": run_id, "task_id": task_id, "agent": agent_slug, "started_at": now()}
    summary = summary_path(run_id)
    summary.parent.mkdir(parents=True, exist_ok=True)
    summary.write_text(
        render_template("summary.md", run_id=run_id, task_id=task_id, agent=agent_slug, now=run["started_at"]),
        encoding="utf-8", newline="\n",
    )
    run_pointer().parent.mkdir(parents=True, exist_ok=True)
    run_pointer().write_text(json.dumps(run, indent=2), encoding="utf-8")
    write_event(run, "run_start")
    task = find_task(task_id)
    if task:
        data, _ = read_fm(task)
        set_fm(task, runs=[*((data or {}).get("runs") or []), run_id])
    return run


def end_run(status: str) -> dict:
    run = current_run()
    summary = summary_path(run["run_id"])
    if summary.is_file():
        set_fm(summary, ended_at=now(), status=status)
    write_event(run, "run_end", status="ok" if status == "success" else status)
    run_pointer().unlink()
    return run


# --------------------------------------------------------------------------- SAF scan
def _names(nodes) -> list[str]:
    out = []
    for node in nodes:
        target = node.func if isinstance(node, ast.Call) else node
        out.append(target.id if isinstance(target, ast.Name) else getattr(target, "attr", ""))
    return out


def scan_source() -> dict:
    """Read the solution's Python source with ast and list steps, transactions and UI pages."""
    source = ROOT / CFG["source_root"]
    result = {"solution": None, "steps": [], "pages": [], "step_attrs": {}}
    solution_dir = source / "solution"
    for path in sorted(solution_dir.glob("*.py")) if solution_dir.is_dir() else []:
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except SyntaxError as exc:
            print(f"warning: cannot parse {rel(path)}: {exc}", file=sys.stderr)
            continue
        for node in [n for n in tree.body if isinstance(n, ast.ClassDef)]:
            bases = _names(node.bases)
            fields = [
                (item.target.id, ast.unparse(item.annotation))
                for item in node.body if isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name)
            ]
            if "StepsModel" in bases:
                result["step_attrs"].update({cls: attr for attr, cls in fields})
            elif "Solution" in bases:
                display = next(
                    (item.value.value for item in node.body
                     if isinstance(item, ast.AnnAssign) and getattr(item.target, "id", "") == "display_name"
                     and isinstance(item.value, ast.Constant)), node.name)
                result["solution"] = {"class": node.name, "display_name": display, "path": rel(path)}
            elif "StepModel" in bases:
                transactions = []
                for item in node.body:
                    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        decorators = _names(item.decorator_list)
                        if "transaction" in decorators or "long_running" in decorators:
                            doc = (ast.get_docstring(item) or "").strip().splitlines()
                            transactions.append({
                                "name": item.name,
                                "kind": "long-running" if "long_running" in decorators else "transaction",
                                "doc": doc[0] if doc else "",
                            })
                result["steps"].append({
                    "class": node.name, "path": rel(path), "doc": (ast.get_docstring(node) or "").strip(),
                    "fields": fields, "transactions": transactions,
                })
    pages_dir = source / "ui" / "pages"
    if pages_dir.is_dir():
        result["pages"] = [rel(p) for p in sorted(pages_dir.glob("*.py")) if p.name != "__init__.py"]
    for step in result["steps"]:
        step["attr"] = result["step_attrs"].get(step["class"], "")
        step["id"] = "step-" + slugify(step["attr"] or step["class"])
    return result


def _step_body(step: dict) -> str:
    lines = [f"# Step: {step['attr'] or step['class']}", "",
             f"`{step['class']}` in `{step['path']}`. {step['doc']}".strip(), "",
             "Draft generated by `agentkit scan`. Check it against the code, then set `last_verified`.", "",
             "## Fields", "", "| Field | Type |", "|---|---|"]
    lines += [f"| `{name}` | `{kind}` |" for name, kind in step["fields"]] or ["| none | |"]
    lines += ["", "## Transactions", "", "| Method | Kind | What it does |", "|---|---|---|"]
    lines += [f"| `{t['name']}` | {t['kind']} | {t['doc']} |" for t in step["transactions"]] or ["| none | | |"]
    lines += ["", "## Gotchas", ""]
    return "\n".join(lines)


def _entity_text(entity_id: str, kind: str, paths: list[str], depends_on: list[str], body: str) -> str:
    stamp = now()
    return (f"---\nid: {entity_id}\ntype: {kind}\nstatus: active\nowner: unassigned\n"
            f"paths: {_fmt_scalar(paths)}\ndepends_on: {_fmt_scalar(depends_on)}\nreplaced_by: null\n"
            f"updated_at: {stamp}\nlast_verified: null\n---\n{body}")


def scan_drift(scan: dict) -> list[str]:
    """Differences between the code and the entity files."""
    notes = []
    entities = {p.stem: p for p in entity_files()}
    for step in scan["steps"]:
        path = entities.get(step["id"])
        if not path:
            notes.append(f"step `{step['class']}` ({step['path']}) has no entity file `{step['id']}.md`")
            continue
        body = path.read_text(encoding="utf-8")
        for name in [t["name"] for t in step["transactions"]] + [f[0] for f in step["fields"]]:
            if f"`{name}`" not in body:
                notes.append(f"{rel(path)} does not mention `{name}` from {step['path']}")
    return notes


def cmd_scan(args) -> None:
    scan = scan_source()
    folder = ROOT / "agent" / "knowledge" / "entities"
    created = []

    def create(entity_id: str, text: str) -> None:
        target = folder / f"{entity_id}.md"
        if not target.exists():
            target.write_text(text, encoding="utf-8", newline="\n")
            created.append(rel(target))

    if not args.report:
        step_ids = [step["id"] for step in scan["steps"]]
        for step in scan["steps"]:
            create(step["id"], _entity_text(step["id"], "step", [step["path"]], [], _step_body(step)))
        if scan["solution"]:
            sol = scan["solution"]
            body = (f"# Solution: {sol['display_name']}\n\n`{sol['class']}` in `{sol['path']}`.\n\n"
                    "Draft generated by `agentkit scan`. Check it against the code, then set `last_verified`.\n\n"
                    "## Steps\n\n" + "\n".join(f"- [{sid}]({sid}.md)" for sid in step_ids) + "\n\n## Gotchas\n")
            create("solution-" + slugify(CFG["solution_name"] or sol["class"]),
                   _entity_text("solution-" + slugify(CFG["solution_name"] or sol["class"]), "solution",
                                [sol["path"]], step_ids, body))
        for page in scan["pages"]:
            page_id = "ui-" + slugify(Path(page).stem)
            body = (f"# UI page: {Path(page).stem}\n\n`{page}`.\n\n"
                    "Draft generated by `agentkit scan`. Describe what the page shows and which step it serves.\n")
            create(page_id, _entity_text(page_id, "ui-page", [page], [], body))
        if args.solution_md and scan["solution"]:
            target = ROOT / Path(scan["solution"]["path"]).parent / "SOLUTION.md"
            if not target.exists():
                steps = "\n".join(
                    f"{i}. On step `{s['attr'] or s['class']}`: "
                    + (", ".join(f"`{t['name']}`" for t in s["transactions"]) or "set its fields; it has no transactions yet")
                    for i, s in enumerate(scan["steps"], 1))
                target.write_text(
                    f"# {scan['solution']['display_name']}\n\n## Instructions\n\n"
                    "Generated draft. State the purpose of this solution and any constraints an agent must respect.\n\n"
                    f"## Workflow\n\n{steps or '1. Describe the order in which transactions must run.'}\n",
                    encoding="utf-8", newline="\n")
                created.append(rel(target))
    for path in created:
        print(f"created {path}")
    drift = scan_drift(scan)
    for note in drift:
        print(f"drift: {note}")
    print(f"scan: {len(scan['steps'])} steps, {sum(len(s['transactions']) for s in scan['steps'])} transactions, "
          f"{len(scan['pages'])} UI pages, {len(created)} files created, {len(drift)} drift notes")


# --------------------------------------------------------------------------- index and find
def build_index() -> tuple[list[dict], list[dict]]:
    records, edges = [], []
    for path in entity_files():
        data, body = read_fm(path)
        if not data:
            continue
        title = next((line[2:].strip() for line in body.splitlines() if line.startswith("# ")), data.get("id"))
        records.append({"kind": "entity", "id": data.get("id"), "type": data.get("type"), "status": data.get("status"),
                        "title": title, "path": rel(path), "paths": data.get("paths") or [],
                        "last_verified": data.get("last_verified"), "updated_at": data.get("updated_at")})
        edges += [{"from": data.get("id"), "to": target, "type": "depends_on"} for target in data.get("depends_on") or []]
        if data.get("replaced_by"):
            edges.append({"from": data.get("id"), "to": data["replaced_by"], "type": "replaced_by"})
    for path in sorted((ROOT / "agent" / "decisions").glob("D-*.md")):
        data, _ = read_fm(path)
        if data:
            records.append({"kind": "decision", "id": data.get("id"), "status": data.get("status"),
                            "title": data.get("title"), "path": rel(path)})
            if data.get("supersedes"):
                edges.append({"from": data.get("id"), "to": data["supersedes"], "type": "supersedes"})
    for status in TASK_STATUS:
        for path in sorted(tasks_dir(status).glob("T-*.md")):
            data, _ = read_fm(path)
            if data:
                records.append({"kind": "task", "id": data.get("id"), "status": status,
                                "title": data.get("title"), "path": rel(path)})
    for path in sorted((ROOT / "agent" / "skills").glob("*/SKILL.md")):
        data, _ = read_fm(path)
        if data:
            records.append({"kind": "skill", "id": data.get("name"), "title": data.get("description"), "path": rel(path)})
    return records, edges


def cmd_index(args) -> None:
    records, edges = build_index()
    folder = ROOT / "local" / "index"
    folder.mkdir(parents=True, exist_ok=True)
    for name, rows in (("entities.jsonl", records), ("edges.jsonl", edges)):
        with (folder / name).open("w", encoding="utf-8", newline="\n") as handle:
            handle.writelines(json.dumps(row, separators=(",", ":")) + "\n" for row in rows)
    print(f"index: {len(records)} records, {len(edges)} edges in local/index/")


def cmd_find(args) -> None:
    records, edges = build_index()
    term = args.term.lower()
    hits = []
    for record in records:
        haystack = json.dumps(record).lower()
        text = (ROOT / record["path"]).read_text(encoding="utf-8").lower()
        if term in haystack or term in text:
            hits.append((0 if term in haystack else 1, record))
    for _, record in sorted(hits, key=lambda hit: hit[0])[: args.limit]:
        print(f"{record['kind']:8} {record['id']}: {record.get('title') or ''}  ({record['path']})")
        if record["kind"] == "entity":
            uses = [e["to"] for e in edges if e["from"] == record["id"] and e["type"] == "depends_on"]
            used_by = [e["from"] for e in edges if e["to"] == record["id"] and e["type"] == "depends_on"]
            if record.get("paths"):
                print(f"         code: {', '.join(record['paths'])}")
            if uses:
                print(f"         depends on: {', '.join(uses)}")
            if used_by:
                print(f"         used by: {', '.join(used_by)}")
    if not hits:
        print(f"no match for '{args.term}'")


# --------------------------------------------------------------------------- validate
def _lines(path: Path) -> int:
    return len(path.read_text(encoding="utf-8").splitlines())


def _check_fm(path: Path, required: list[str], errors: list[str]) -> dict | None:
    data, _ = read_fm(path)
    if data is None:
        errors.append(f"{rel(path)}: missing frontmatter")
        return None
    missing = [key for key in required if key not in data]
    if missing:
        errors.append(f"{rel(path)}: missing fields {', '.join(missing)}")
    return data


def validate(ci: bool = False, full: bool = False) -> tuple[list[str], list[str]]:
    errors, warnings = [], []
    limits = CFG["size_limits"]
    agent = ROOT / "agent"

    for required in ["AGENTS.md", "agent/standard.md", "agent/skills", "agent/templates", "agent/knowledge/entities",
                     "agent/architecture", "agent/decisions", "agent/logs", "agent/tasks/backlog",
                     "agent/tasks/active", "agent/tasks/done"]:
        if not (ROOT / required).exists():
            errors.append(f"missing {required}")

    def limit(path: Path, key: str) -> None:
        count = _lines(path)
        if count > limits[key]:
            errors.append(f"{rel(path)}: {count} lines, limit is {limits[key]}")

    if (ROOT / "AGENTS.md").is_file():
        limit(ROOT / "AGENTS.md", "agents_md")
        if "agent-layer" not in (ROOT / "AGENTS.md").read_text(encoding="utf-8"):
            errors.append("AGENTS.md has no agent-layer section. Run the installer again.")
        placeholders = (ROOT / "AGENTS.md").read_text(encoding="utf-8").count("[fill in:")
        if placeholders:
            warnings.append(f"AGENTS.md still has {placeholders} placeholders to fill in")

    entity_ids = {}
    for path in entity_files():
        data = _check_fm(path, ["id", "type", "status", "paths", "depends_on", "updated_at", "last_verified"], errors)
        limit(path, "entity")
        if not data:
            continue
        entity_ids[data.get("id")] = (path, data)
        if data.get("id") != path.stem:
            errors.append(f"{rel(path)}: id `{data.get('id')}` does not match the file name")
        if data.get("type") not in CFG["entity_types"]:
            errors.append(f"{rel(path)}: type `{data.get('type')}` is not one of {', '.join(CFG['entity_types'])}")
        if data.get("status") not in ENTITY_STATUS:
            errors.append(f"{rel(path)}: status `{data.get('status')}` is not one of {', '.join(ENTITY_STATUS)}")
        if data.get("status") != "deprecated":
            for code_path in data.get("paths") or []:
                if not (ROOT / str(code_path)).exists():
                    errors.append(f"{rel(path)}: path `{code_path}` does not exist")
    for entity_id, (path, data) in entity_ids.items():
        for target in [*(data.get("depends_on") or []), data.get("replaced_by")]:
            if target and target not in entity_ids:
                errors.append(f"{rel(path)}: links to unknown entity `{target}`")

    task_ids = {}
    for status in TASK_STATUS:
        for path in sorted(tasks_dir(status).glob("*.md")):
            data = _check_fm(path, ["id", "title", "status", "created_at"], errors)
            if not data:
                continue
            task_id = str(data.get("id"))
            if not TASK_ID_RE.fullmatch(task_id) or not path.name.startswith(task_id + "-"):
                errors.append(f"{rel(path)}: id and file name must look like T-0042-short-name")
            if task_id in task_ids:
                errors.append(f"{rel(path)}: duplicate task id {task_id}, also in {rel(task_ids[task_id])}")
            task_ids[task_id] = path
            if data.get("status") != status:
                errors.append(f"{rel(path)}: status `{data.get('status')}` but the file is in tasks/{status}/")

    decisions = {}
    for path in sorted((agent / "decisions").glob("*.md")):
        data = _check_fm(path, ["id", "title", "status", "created_at"], errors)
        if not data:
            continue
        decision_id = str(data.get("id"))
        if not DECISION_ID_RE.fullmatch(decision_id) or not path.name.startswith(decision_id + "-"):
            errors.append(f"{rel(path)}: id and file name must look like D-0007-short-name")
        if data.get("status") not in DECISION_STATUS:
            errors.append(f"{rel(path)}: status `{data.get('status')}` is not one of {', '.join(DECISION_STATUS)}")
        decisions[decision_id] = data
    for decision_id, data in decisions.items():
        if data.get("supersedes") and data["supersedes"] not in decisions:
            errors.append(f"decision {decision_id}: supersedes unknown decision `{data['supersedes']}`")

    for path in sorted((agent / "logs").glob("*/*.md")):
        data = _check_fm(path, ["run_id", "task_id", "agent", "started_at", "status"], errors)
        limit(path, "summary")
        if data:
            if data.get("run_id") != path.stem:
                errors.append(f"{rel(path)}: run_id does not match the file name")
            if data.get("task_id") not in task_ids:
                errors.append(f"{rel(path)}: task `{data.get('task_id')}` does not exist")
            if data.get("status") not in RUN_STATUS:
                errors.append(f"{rel(path)}: status `{data.get('status')}` is not one of {', '.join(RUN_STATUS)}")

    for folder in sorted(p for p in (agent / "skills").glob("*") if p.is_dir()):
        skill = folder / "SKILL.md"
        if not skill.is_file():
            errors.append(f"{rel(folder)}: missing SKILL.md")
            continue
        data = _check_fm(skill, ["name", "description"], errors)
        limit(skill, "skill")
        if data and data.get("name") != folder.name:
            errors.append(f"{rel(skill)}: name `{data.get('name')}` does not match the folder name")

    for path in sorted((agent / "architecture").glob("*.md")):
        limit(path, "architecture")

    link_re = re.compile(r"\]\(([^)\s#]+)(?:#[^)]*)?\)")
    for path in [ROOT / "AGENTS.md", *sorted(agent.rglob("*.md"))]:
        if not path.is_file() or "templates" in path.parts:
            continue
        text = re.sub(r"```.*?```", "", path.read_text(encoding="utf-8"), flags=re.S)
        for target in link_re.findall(text):
            if re.match(r"[a-z][a-z0-9+.-]*:", target) or target.startswith("<"):
                continue
            if not (path.parent / target).exists():
                errors.append(f"{rel(path)}: broken link `{target}`")

    env_file = ROOT / ".env"
    if env_file.is_file():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                key, value = line.split("=", 1)
                if SECRET_KEY_RE.search(key) and value.strip().strip("\"'"):
                    errors.append(f".env: `{key.strip()}` looks like a secret. Move it to local/secrets.env")

    if in_git():
        tracked = git("ls-files", "--", "local", check=False).stdout.split()
        if tracked:
            errors.append(f"files under local/ are tracked by git: {', '.join(tracked[:5])}")
        branch = current_branch()
        if branch and branch not in ("HEAD", CFG["base_branch"]) and branch_problem(branch):
            warnings.append(branch_problem(branch))

    if not ci:
        listed = {}
        manifest = ROOT / "local.manifest.jsonl"
        for number, line in enumerate(manifest.read_text(encoding="utf-8").splitlines() if manifest.is_file() else [], 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                errors.append(f"local.manifest.jsonl line {number}: not valid JSON")
                continue
            missing = [key for key in MANIFEST_FIELDS if key not in row]
            if missing or row.get("kind") not in MANIFEST_KINDS:
                errors.append(f"local.manifest.jsonl line {number}: bad or missing fields")
                continue
            listed[row["path"]] = row
            target = ROOT / row["path"]
            if not target.is_file():
                warnings.append(f"manifest lists {row['path']} but the file is not on this machine")
            elif target.stat().st_size != row["size"]:
                errors.append(f"{row['path']}: size differs from the manifest. Run manifest-add again")
            elif full and sha256(target) != row["sha256"]:
                errors.append(f"{row['path']}: checksum differs from the manifest")
        for name in IRREPLACEABLE_DIRS:
            for path in sorted((ROOT / "local" / name).rglob("*")) if (ROOT / "local" / name).is_dir() else []:
                if path.is_file() and path.name != ".gitkeep" and rel(path) not in listed:
                    errors.append(f"{rel(path)} is not in local.manifest.jsonl. Run: manifest-add {rel(path)}")

    warnings += [f"drift: {note}" for note in scan_drift(scan_source())]
    return errors, warnings


def cmd_validate(args) -> None:
    errors, warnings = validate(ci=args.ci, full=args.full)
    for warning in warnings:
        print(f"warning: {warning}")
    for error in errors:
        print(f"error: {error}")
    print(f"validate: {len(errors)} errors, {len(warnings)} warnings")
    sys.exit(1 if errors else 0)


# --------------------------------------------------------------------------- git rules
def branch_problem(branch: str) -> str | None:
    if branch == CFG["base_branch"] or any(branch.startswith(p) for p in CFG["exempt_branch_prefixes"]):
        return None
    pattern = rf"^({'|'.join(CFG['branch_types'])})/T-\d{{4}}-[a-z0-9][a-z0-9-]*$"
    if re.match(pattern, branch):
        return None
    return f"branch `{branch}` should look like {CFG['branch_types'][0]}/T-0042-short-name"


def commit_problem(message: str, branch: str = "") -> str | None:
    subject = next((line for line in message.splitlines() if line.strip() and not line.startswith("#")), "")
    if re.match(r"^(Merge |Revert |fixup! |squash! )", subject):
        return None
    types = "|".join(CFG["commit_types"])
    if not re.match(rf"^({types})(\([a-z0-9-]+\))?!?: \S", subject):
        return f"`{subject}` must start with a type: {types.replace('|', ', ')}. Example: feat: add export [T-0042]"
    if len(subject) > 100:
        return f"subject has {len(subject)} characters, limit is 100"
    branch_task = TASK_ID_RE.search(branch)
    if branch_task and f"[{branch_task.group(0)}]" not in subject:
        return f"subject must carry the task id of this branch: [{branch_task.group(0)}]"
    return None


def cmd_check_commit_msg(args) -> None:
    problem = commit_problem(Path(args.file).read_text(encoding="utf-8"), current_branch() if in_git() else "")
    if problem:
        die(f"commit message: {problem}")


def cmd_check_commits(args) -> None:
    subjects = git("log", "--no-merges", "--format=%s", args.range).stdout.splitlines()
    problems = [p for p in (commit_problem(s, args.branch or "") for s in subjects) if p]
    for problem in problems:
        print(f"error: {problem}")
    print(f"check-commits: {len(subjects)} commits, {len(problems)} problems")
    sys.exit(1 if problems else 0)


def cmd_check_branch(args) -> None:
    problem = branch_problem(args.branch or current_branch())
    if problem:
        die(problem)
    print("check-branch: ok")


HOOK_SHIM = """#!/bin/sh
# Installed by agentkit hooks-install. Runs the agent layer check for this hook.
PY=$(command -v python3 || command -v python) || { echo "agentkit: python not found" >&2; exit 1; }
cd "$(git rev-parse --show-toplevel)/__PREFIX__" && exec "$PY" agent/tools/agentkit.py __COMMAND__
"""


def cmd_hooks_install(args) -> None:
    top = Path(git("rev-parse", "--show-toplevel").stdout.strip())
    hooks = Path(git("rev-parse", "--git-path", "hooks").stdout.strip())
    hooks = hooks if hooks.is_absolute() else ROOT / hooks
    hooks.mkdir(parents=True, exist_ok=True)
    prefix = ROOT.resolve().relative_to(top.resolve()).as_posix()
    for name, command in (("pre-commit", "validate"), ("commit-msg", 'check-commit-msg "$1"')):
        target = hooks / name
        if target.exists() and not args.force and "agentkit" not in target.read_text(encoding="utf-8", errors="ignore"):
            print(f"kept existing {name} hook (managed by another tool). Use --force to replace it")
            continue
        target.write_text(HOOK_SHIM.replace("__PREFIX__", prefix).replace("__COMMAND__", command),
                          encoding="utf-8", newline="\n")
        target.chmod(0o755)
        print(f"installed {name} hook")


# --------------------------------------------------------------------------- tasks
def cmd_task_new(args) -> None:
    task_id = next_id("T", [tasks_dir(s) for s in TASK_STATUS])
    path = tasks_dir("backlog") / f"{task_id}-{slugify(args.title)}.md"
    path.write_text(render_template("task.md", id=task_id, title=_fmt_scalar(args.title), now=now()),
                    encoding="utf-8", newline="\n")
    print(f"created {rel(path)}")


def cmd_task_list(args) -> None:
    claimed = git("ls-remote", "--heads", "origin", check=False).stdout if in_git() and has_remote() and args.remote else ""
    for status in TASK_STATUS if args.all else ["backlog", "active"]:
        for path in sorted(tasks_dir(status).glob("T-*.md")):
            data, _ = read_fm(path)
            note = ""
            if status == "backlog" and re.search(rf"/{data.get('id')}-", claimed):
                note = "  (claimed on a remote branch)"
            owner = f"  [{data.get('claimed_by')}]" if data.get("claimed_by") else ""
            print(f"{status:8} {data.get('id')}  {data.get('title')}{owner}{note}")


def cmd_task_claim(args) -> None:
    source = find_task(args.id, "backlog")
    if not source:
        die(f"{args.id} is not in agent/tasks/backlog/")
    if args.type not in CFG["branch_types"]:
        die(f"type must be one of {', '.join(CFG['branch_types'])}")
    if git("status", "--porcelain").stdout.strip():
        die("the working tree has uncommitted changes. Commit or stash them before claiming a task")
    base = current_branch()
    branch = f"{args.type}/{source.stem}"
    push = has_remote() and not args.no_push
    if push and not args.skip_remote_check:
        heads = git("ls-remote", "--heads", "origin", check=False).stdout
        taken = re.search(rf"refs/heads/(\S+/{args.id}-\S*)", heads)
        if taken:
            die(f"{args.id} is already claimed on remote branch {taken.group(1)}")
    if git("rev-parse", "--verify", "--quiet", f"refs/heads/{branch}", check=False).returncode == 0:
        die(f"local branch {branch} already exists")

    git("checkout", "-b", branch)
    target = tasks_dir("active") / source.name
    git("mv", rel(source), rel(target))
    agent = args.agent or os.environ.get("AGENT_NAME") or "agent"
    set_fm(target, status="active", claimed_at=now(), claimed_by=slugify(agent, 20))
    run = start_run(args.id, agent)
    git("add", "agent")
    commit = git("commit", "-m", f"chore: claim task [{args.id}]", check=False)
    pushed = None
    if commit.returncode == 0 and push:
        pushed = git("push", f"--force-with-lease=refs/heads/{branch}:", "-u", "origin", branch, check=False)
    if commit.returncode != 0 or (pushed is not None and pushed.returncode != 0):
        reason = (commit.stderr or commit.stdout) if commit.returncode != 0 else (pushed.stderr or pushed.stdout)
        shutil.rmtree(events_path(run["run_id"]).parent, ignore_errors=True)
        run_pointer().unlink(missing_ok=True)
        git("reset", "--hard", "-q", check=False)
        git("checkout", "-q", base, check=False)
        git("branch", "-D", branch, check=False)
        die(f"could not claim {args.id}; nothing was changed. Reason: {reason.strip()}")
    print(f"claimed {args.id} on branch {branch}" + ("" if push else " (not pushed: no remote)"))
    print(f"run {run['run_id']} is open. Summary: {rel(summary_path(run['run_id']))}")


def _section_has_content(body: str, heading: str) -> bool:
    match = re.search(rf"^## {re.escape(heading)}\s*\n(.*?)(?=^## |\Z)", body, re.S | re.M)
    return bool(match and match.group(1).strip())


def cmd_task_done(args) -> None:
    source = find_task(args.id, "active")
    if not source:
        die(f"{args.id} is not in agent/tasks/active/")
    if args.id not in current_branch() and not args.force:
        die(f"you are on `{current_branch()}`, not on the branch of {args.id}. Use --force to override")
    run = current_run()
    if run["task_id"] != args.id:
        die(f"the open run belongs to {run['task_id']}, not {args.id}")
    summary = summary_path(run["run_id"])
    if not summary.is_file() or not _section_has_content(read_fm(summary)[1], "What changed"):
        die(f"write the run summary first: {rel(summary)} needs content under '## What changed'")
    if not args.no_check:
        try:
            result = subprocess.run(CFG["check_command"], cwd=ROOT)
        except FileNotFoundError:
            die(f"check command not found: {' '.join(CFG['check_command'])}. Install it or change check_command in agent/config.json")
        if result.returncode != 0:
            write_event(run, "check", tool=" ".join(CFG["check_command"]), status="error", error="check failed")
            die("the check command failed. Fix it, then run task-done again")
    errors, warnings = validate()
    drift = [w for w in warnings if w.startswith("drift:")]
    if drift and not args.allow_drift:
        errors += [w + " (update the entity file, or pass --allow-drift)" for w in drift]
    if errors:
        for error in errors:
            print(f"error: {error}")
        die("validation failed. Fix the errors above, then run task-done again")

    target = tasks_dir("done") / source.name
    git("mv", rel(source), rel(target))
    set_fm(target, status="done", done_at=now())
    end_run(args.status)
    cmd_index(args)
    if not args.no_commit:
        git("add", "agent", "local.manifest.jsonl")
        git("commit", "-m", f"chore: complete task [{args.id}]")
    print(f"{args.id} is done. Next: push the branch and open a pull request")


def cmd_run_start(args) -> None:
    if not find_task(args.id, "active"):
        die(f"{args.id} is not in agent/tasks/active/. Claim it first")
    run = start_run(args.id, args.agent or os.environ.get("AGENT_NAME") or "agent")
    print(f"run {run['run_id']} is open. Summary: {rel(summary_path(run['run_id']))}")


def cmd_run_end(args) -> None:
    run = end_run(args.status)
    print(f"run {run['run_id']} closed with status {args.status}")


def cmd_log(args) -> None:
    extra = {}
    for item in args.data or []:
        if "=" not in item:
            die(f"--data needs key=value, got `{item}`")
        key, value = item.split("=", 1)
        extra[key] = value
    write_event(current_run(), args.event, tool=args.tool, status=args.status, duration_ms=args.duration_ms,
                tokens=args.tokens, error=args.error, extra=extra)


def cmd_status(args) -> None:
    run = current_run(required=False)
    print(f"solution: {CFG['solution_name'] or '(unnamed)'}  root: {ROOT}")
    if in_git():
        print(f"branch:   {current_branch()}")
    print(f"run:      {run['run_id']} for {run['task_id']}" if run else "run:      none open")
    for status in TASK_STATUS:
        print(f"{status + ':':9} {len(list(tasks_dir(status).glob('T-*.md')))} tasks")


def _new_from_template(folder: Path, prefix: str, template: str, title: str) -> None:
    new_id = next_id(prefix, [folder])
    path = folder / f"{new_id}-{slugify(title)}.md"
    path.write_text(render_template(template, id=new_id, title=_fmt_scalar(title), now=now()),
                    encoding="utf-8", newline="\n")
    print(f"created {rel(path)}")


def cmd_decision_new(args) -> None:
    _new_from_template(ROOT / "agent" / "decisions", "D", "decision.md", args.title)


def cmd_entity_new(args) -> None:
    entity_id = slugify(args.id, 60)
    path = ROOT / "agent" / "knowledge" / "entities" / f"{entity_id}.md"
    if path.exists():
        die(f"{rel(path)} already exists")
    if args.type not in CFG["entity_types"]:
        die(f"type must be one of {', '.join(CFG['entity_types'])}")
    path.write_text(render_template("entity.md", id=entity_id, type=args.type, now=now()), encoding="utf-8", newline="\n")
    print(f"created {rel(path)}")


# --------------------------------------------------------------------------- local files
def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def cmd_manifest_add(args) -> None:
    target = (Path.cwd() / args.path).resolve() if not Path(args.path).is_absolute() else Path(args.path)
    if not target.is_file():
        target = ROOT / args.path
    if not target.is_file():
        die(f"{args.path} is not a file")
    key = rel(target)
    if not key.startswith("local/"):
        die("only files under local/ belong in the manifest")
    manifest = ROOT / "local.manifest.jsonl"
    rows = [json.loads(line) for line in manifest.read_text(encoding="utf-8").splitlines() if line.strip()] if manifest.is_file() else []
    previous = next((row for row in rows if row["path"] == key), {})
    run = current_run(required=False)
    row = {"path": key, "kind": args.kind or previous.get("kind") or ("data" if key.startswith("local/data/") else "asset" if key.startswith("local/assets/") else "artifact"),
           "size": target.stat().st_size, "sha256": sha256(target),
           "source": args.source or previous.get("source") or "",
           "produced_by": previous.get("produced_by") or (run["run_id"] if run and key.startswith("local/artifacts/") else None),
           "updated_at": now()}
    rows = sorted([r for r in rows if r["path"] != key] + [row], key=lambda r: r["path"])
    manifest.write_text("".join(json.dumps(r, separators=(",", ":")) + "\n" for r in rows), encoding="utf-8", newline="\n")
    print(f"manifest: {key} ({row['size']} bytes)" + ("" if row["source"] else "  note: add --source to record where the master copy lives"))


def cmd_compact(args) -> None:
    days = args.days if args.days is not None else CFG["log_retention_days"]
    cutoff = (dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=days)).strftime("%Y-%m-%d")
    logs = ROOT / "local" / "logs"
    archive = logs / "archive"
    moved = 0
    for folder in sorted(p for p in logs.glob("????-??-??") if p.is_dir() and p.name < cutoff):
        archive.mkdir(parents=True, exist_ok=True)
        with gzip.open(archive / f"{folder.name[:7]}.jsonl.gz", "ab") as out:
            for path in sorted(folder.glob("*.jsonl")):
                out.write(path.read_bytes())
                moved += 1
        shutil.rmtree(folder)
    print(f"compact: archived {moved} run logs older than {days} days into local/logs/archive/")


def cmd_env_merge(args) -> None:
    values, order = {}, []
    for name in [".env", "local/secrets.env"]:
        path = ROOT / name
        for line in path.read_text(encoding="utf-8").splitlines() if path.is_file() else []:
            if "=" in line and not line.lstrip().startswith("#"):
                key = line.split("=", 1)[0].strip()
                if key not in values:
                    order.append(key)
                values[key] = line.strip()
    target = ROOT / "local" / "run.env"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("# Generated by agentkit env-merge from .env and local/secrets.env. Do not edit.\n"
                      + "".join(values[key] + "\n" for key in order), encoding="utf-8", newline="\n")
    print(f"env-merge: wrote local/run.env with {len(order)} variables")


def cmd_archive_clean(args) -> None:
    source = Path(args.archive)
    if not source.is_file():
        die(f"{args.archive} is not a file")
    drop = [name for name in ARCHIVE_DROP if not (name == "legacy" and args.keep_legacy)]
    temp = source.with_suffix(source.suffix + ".tmp")
    removed = 0
    with zipfile.ZipFile(source) as original, zipfile.ZipFile(temp, "w", zipfile.ZIP_DEFLATED) as cleaned:
        for item in original.infolist():
            first = item.filename.replace("\\", "/").split("/", 1)[0]
            if first in drop:
                removed += 1
            else:
                cleaned.writestr(item, original.read(item.filename))
    temp.replace(source)
    print(f"archive-clean: removed {removed} entries under {', '.join(name + '/' for name in drop)} from {source.name}")


# --------------------------------------------------------------------------- cli
def main(argv: list[str] | None = None) -> None:
    global ROOT, CFG
    parser = argparse.ArgumentParser(prog="agentkit", description="Tooling for the agent layer of a SAF solution.")
    parser.add_argument("--version", action="version", version=VERSION)
    sub = parser.add_subparsers(dest="command", required=True)

    def add(name: str, func, help_text: str):
        command = sub.add_parser(name, help=help_text)
        command.set_defaults(func=func)
        return command

    p = add("validate", cmd_validate, "check the solution against the standard")
    p.add_argument("--ci", action="store_true", help="skip checks that need local/")
    p.add_argument("--full", action="store_true", help="also verify manifest checksums")
    p = add("scan", cmd_scan, "create draft entity files from the SAF source and report drift")
    p.add_argument("--report", action="store_true", help="report drift only, create nothing")
    p.add_argument("--solution-md", action="store_true", help="also create SOLUTION.md for the MCP server if missing")
    add("index", cmd_index, "rebuild local/index/")
    p = add("find", cmd_find, "look up entities, decisions, tasks and skills")
    p.add_argument("term")
    p.add_argument("--limit", type=int, default=20)
    p = add("task-new", cmd_task_new, "create a task in the backlog")
    p.add_argument("title")
    p = add("task-list", cmd_task_list, "list tasks")
    p.add_argument("--all", action="store_true", help="include done tasks")
    p.add_argument("--remote", action="store_true", help="mark backlog tasks already claimed on the remote")
    p = add("task-claim", cmd_task_claim, "claim a task: branch, move to active, open a run, push")
    p.add_argument("id")
    p.add_argument("--type", default="feature")
    p.add_argument("--agent")
    p.add_argument("--no-push", action="store_true")
    p.add_argument("--skip-remote-check", action="store_true", help=argparse.SUPPRESS)
    p = add("task-done", cmd_task_done, "close a task after checks pass")
    p.add_argument("id")
    p.add_argument("--status", default="success", choices=["success", "partial", "failed"])
    p.add_argument("--no-check", action="store_true", help="skip the check command (CI still runs it)")
    p.add_argument("--no-commit", action="store_true")
    p.add_argument("--allow-drift", action="store_true", help="close even if entity files lag behind the code")
    p.add_argument("--force", action="store_true")
    p = add("run-start", cmd_run_start, "open a new run for an active task")
    p.add_argument("id")
    p.add_argument("--agent")
    p = add("run-end", cmd_run_end, "close the open run without closing the task")
    p.add_argument("--status", default="partial", choices=["success", "partial", "failed"])
    p = add("log", cmd_log, "append one event to the open run")
    p.add_argument("event")
    p.add_argument("--tool")
    p.add_argument("--status", default="ok")
    p.add_argument("--duration-ms", type=int)
    p.add_argument("--tokens", type=int)
    p.add_argument("--error")
    p.add_argument("--data", action="append", metavar="KEY=VALUE")
    add("status", cmd_status, "show the current branch, run and task counts")
    p = add("decision-new", cmd_decision_new, "create a decision record")
    p.add_argument("title")
    p = add("entity-new", cmd_entity_new, "create an entity file")
    p.add_argument("id")
    p.add_argument("--type", default="component")
    p = add("manifest-add", cmd_manifest_add, "add or refresh a file in local.manifest.jsonl")
    p.add_argument("path")
    p.add_argument("--kind", choices=MANIFEST_KINDS)
    p.add_argument("--source", help="where the master copy lives")
    p = add("compact", cmd_compact, "archive old run events")
    p.add_argument("--days", type=int)
    add("env-merge", cmd_env_merge, "merge .env and local/secrets.env into local/run.env")
    p = add("archive-clean", cmd_archive_clean, "remove local/ and legacy/ from a .saf archive")
    p.add_argument("archive")
    p.add_argument("--keep-legacy", action="store_true")
    p = add("check-commit-msg", cmd_check_commit_msg, "validate a commit message file")
    p.add_argument("file")
    p = add("check-commits", cmd_check_commits, "validate the commit subjects in a range")
    p.add_argument("range")
    p.add_argument("--branch")
    p = add("check-branch", cmd_check_branch, "validate a branch name")
    p.add_argument("branch", nargs="?")
    p = add("hooks-install", cmd_hooks_install, "install native git hooks")
    p.add_argument("--force", action="store_true")

    args = parser.parse_args(argv)
    ROOT = find_root()
    CFG = load_config(ROOT)
    try:
        args.func(args)
    except BrokenPipeError:
        sys.stderr.close()


if __name__ == "__main__":
    main()
