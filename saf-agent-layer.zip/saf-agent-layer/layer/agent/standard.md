# Agent layer standard for SAF solutions

Version 4 (SAF edition)

This solution is built with the Solution Application Framework (SAF). SAF owns the application: its structure, environment, run and packaging. The agent layer adds what agents need to work on it without scanning the whole project: knowledge, tasks, run logs, skills and git rules.

## 1. Principles

1. **SAF is the host.** Never fight SAF's layout or tooling. Application work goes through the `saf` CLI.
2. **The repository is the agent's memory.** Whatever an agent needs must be findable from `AGENTS.md`.
3. **Map first, detail on demand.** Read the map, then open only the files you need.
4. **Generate, do not write.** Entity drafts, the index, timestamps and log lines come from tools.
5. **One command surface.** Every operation is a `just` recipe. Without `just`, call `python agent/tools/agentkit.py <command>`.
6. **One ignored directory.** Everything that stays out of git lives in `local/`.
7. **Small files.** Every file an agent reads has a size limit.

## 2. Who owns what

| Area | Owner | Location |
|---|---|---|
| Solution code: steps, transactions, UI | SAF | `src/` |
| Tests | SAF | `tests/` |
| User documentation (Sphinx) | SAF | `doc/` |
| Deployment recipes | SAF | `deployments/` |
| Environment and dependencies | SAF, through `saf install` and Poetry | `.venv/`, `.poetry/`, `pyproject.toml`, `poetry.lock` |
| Runtime configuration | SAF | `.env` (tracked, no secrets) |
| Guidance for agents driving the running app | SAF's MCP server | `SOLUTION.md` beside `definition.py` |
| Knowledge, tasks, logs, skills, tools | Agent layer | `agent/` |
| Data, heavy assets, secrets, index, run events | Agent layer | `local/` (ignored) |
| Old project being migrated | Agent layer | `legacy/` |

## 3. Structure

```
<solution>/
├── AGENTS.md                  SAF's guide plus the agent-layer section
├── justfile                   all commands
├── local.manifest.jsonl       list of irreplaceable files kept in local/
├── agent/
│   ├── standard.md            this document
│   ├── config.json            layer settings
│   ├── skills/                one folder per procedure, each with SKILL.md
│   ├── templates/             entity, task, decision and summary templates
│   ├── architecture/          how parts work
│   ├── decisions/             numbered, append-only decision records
│   ├── knowledge/entities/    one file per step, UI page, service or data set
│   ├── tasks/                 backlog/ active/ done/
│   ├── logs/                  run summaries: <date>/<run-id>.md
│   ├── artifacts/             small agent outputs
│   └── tools/agentkit.py      the tooling
├── legacy/                    migrated projects only: the old project, untouched
├── local/                     ignored by git
│   ├── index/                 rebuildable: entities.jsonl, edges.jsonl
│   ├── logs/                  run events: <date>/<run-id>.jsonl, archive/
│   ├── run/                   pointer to the open run
│   ├── data/                  irreplaceable
│   ├── assets/                irreplaceable
│   ├── artifacts/             heavy agent outputs, irreplaceable
│   ├── secrets.env            secrets, never committed
│   └── run.env                generated: .env plus secrets.env
└── src/  tests/  doc/  deployments/  .env  pyproject.toml     owned by SAF
```

### When to read what

| Location | Read it |
|---|---|
| `AGENTS.md` | At the start of every run |
| `agent/skills/` | When the task calls for that procedure |
| `agent/knowledge/entities/` | When you need facts about a step, transaction, page or data set |
| `agent/architecture/` | Before changing how parts work together |
| `agent/decisions/` | Before changing a design |
| `agent/tasks/` | To pick up work and record status |
| `agent/logs/` | To learn what earlier runs did. Open events in `local/logs/` only when debugging |
| `local.manifest.jsonl` | To learn what data and heavy assets exist without opening them |
| `SOLUTION.md` | Before driving the running solution through the MCP server |
| `legacy/` | Only when a task or an entity points there |

### What lives in `local/`

| Kind | Folders | Rule |
|---|---|---|
| Rebuildable | `index/`, `run.env` | Recreated by `just index` and `just run` |
| Disposable | `logs/`, `run/` | Run events. The summaries in git are the lasting record |
| Irreplaceable | `data/`, `assets/`, `artifacts/` | Every file is in `local.manifest.jsonl` and backed up off the machine |
| Secret | `secrets.env` | Never committed, never logged |

The environment is not in `local/`. SAF keeps it in `.venv/` and `.poetry/`, which SAF's own `.gitignore` already covers.

## 4. Conventions

| Thing | Convention | Example |
|---|---|---|
| Files and folders in `agent/` | Lowercase kebab-case | `step-meshing.md` |
| Task | `T-` plus four digits, then a short name | `T-0042-add-csv-export.md` |
| Decision | `D-` plus four digits, then a short name | `D-0007-split-solve-step.md` |
| Entity ID | Same as its file name | `step-meshing` |
| Run ID | UTC time, agent name, four hex characters | `20261122T154100Z-builder-a3f9` |
| Branch | SAF branch type, then the task file name | `feature/T-0042-add-csv-export` |
| Commit | Conventional commit, then the task ID | `feat: add CSV export [T-0042]` |
| Timestamps | UTC in ISO 8601, from the system clock | `2026-11-22T15:41:00Z` |

Branch types are `feature`, `bugfix`, `hotfix` and `refactor`, as in SAF. Commit types are `feat`, `fix`, `docs`, `chore`, `refactor` and `test`.

Entity types are `solution`, `step`, `ui-page`, `component`, `service`, `product`, `data`, `config` and `external`.

Size limits: `AGENTS.md` 250 lines, a skill 200, an entity 100, an architecture doc 200, a run summary 40. They are set in `agent/config.json` and enforced by `just validate`.

Writing style: one topic per file, lead with the fact, cite code by path, state each fact once and link to it, and mark anything unconfirmed as unverified. Python code follows SAF: PEP 8, 120 characters, type hints and numpydoc docstrings.

## 5. Process

Every agent run follows the same seven steps.

1. Read `AGENTS.md`.
2. Run `just task-claim <id>`. It creates the branch, moves the task to `active/`, opens a run and pushes the claim.
3. Load the matching skill. Use `just find <term>` to locate the few files you need.
4. Do the work. Record notable events with `just log <event>`.
5. Run `just check` until it passes.
6. Update the entity files you touched, add a decision record if the design changed, and fill in the run summary.
7. Run `just task-done <id>`. It runs the checks and validation, closes the run, moves the task to `done/` and commits. Then push and open a pull request.

A task that spans several sessions uses `just run-end` to pause and `just run-start <id>` to resume. Each session is its own run.

## 6. Rules

### Git

- `local/` is never committed. `just validate` fails if it is.
- One agent works on one task, on its own branch. A claim is the creation of the task branch on the remote, so the first agent to push wins.
- Never bypass hooks with `--no-verify`. Fix the cause.
- A pull request merges only when CI passes: SAF's workflows and the `Agent layer` workflow.
- Generated files (`local/index/`, `local/run.env`) are never edited by hand.

### Safety

- Secrets live in `local/secrets.env` or real environment variables. `.env` is tracked by SAF and must hold no secret.
- A human approves irreversible actions: deploys, deletes, spending, and data or project migrations.
- Before sharing a `.saf` archive, run `just archive-clean <file>`. `saf archive` packs the whole solution folder, including `local/` and `legacy/`.

### Knowledge

- A task is done only when `just task-done` succeeds.
- When a task touches something undocumented, documenting it is part of the task.
- `last_verified` is set only after checking the entity file against the code.
- Accepted decisions are never edited. Write a new record that supersedes the old one.
- Keep `SOLUTION.md` in step with the transactions, because agents driving the app rely on it.

### SAF coding rules

These come from SAF's best-practice guides. Read the guides in SAF's documentation for the details.

- No code runs when a step module is imported. Put logic in methods and import heavy packages inside them.
- Every step field has a default value.
- No module-level globals, and no session state kept in memory. State lives in step fields.
- Write business logic as plain functions, test them alone, then wire them into transactions.
- One step per logical concern. Keep the step dependency graph shallow and declare cross-step reads explicitly.
- Use long-running transactions for slow work.
- Never modify data that an entity handle refers to.
- Read environment variables with `os.getenv` or Pydantic settings. Do not call `load_dotenv()`.
- Change dependencies only through `saf execute <solution> "poetry ..."`. Never edit `pyproject.toml` or `poetry.lock` by hand.

## 7. Commands

| Recipe | What it does |
|---|---|
| `just setup` | Installs the solution environment with `saf install` and rebuilds the index |
| `just check` | Tests, style hooks and validation |
| `just run`, `just run-api` | Runs the solution, or only its backend, with secrets merged in |
| `just add-step <name> <template>` | Adds a step with `saf add-step` and drafts its entity file |
| `just scan` | Drafts entity files from the source and reports drift between code and knowledge |
| `just find <term>` | Looks up entities, decisions, tasks and skills |
| `just validate` | Checks the solution against this standard |
| `just task-new`, `task-list`, `task-claim`, `task-done` | Task workflow |
| `just run-start`, `run-end`, `log`, `status` | Run workflow |
| `just decision-new`, `entity-new` | New records from templates |
| `just manifest-add <path>` | Registers a file in `local/data/`, `local/assets/` or `local/artifacts/` |
| `just compact` | Archives run events older than 30 days |
| `just hooks`, `just hooks-native` | Installs git hooks through pre-commit, or as plain hooks |
| `just docs`, `build`, `archive`, `archive-clean` | SAF documentation, installer and archive |

`just validate` checks that required folders exist, frontmatter is complete, IDs match file names, links resolve, size limits hold, nothing under `local/` is tracked, `.env` holds no secret, and every irreplaceable file is in the manifest. It also warns about drift between the code and the entity files.

## 8. Logs

Each run produces two files that share the run ID.

| File | Location | In git | Purpose |
|---|---|---|---|
| Summary | `agent/logs/<date>/<run-id>.md` | Yes | What changed, what failed, what is next |
| Events | `local/logs/<date>/<run-id>.jsonl` | No | One line per event, for debugging |

Every event line has the fields `ts`, `run_id`, `task_id`, `agent`, `event`, `tool`, `status`, `duration_ms`, `tokens` and `error`. Events older than the retention period are compacted into `local/logs/archive/<month>.jsonl.gz`.

These are the agent's logs. The solution's own logs and traces come from SAF's logging and OpenTelemetry support; see SAF's debugging guide.

## 9. Driving the solution through MCP

SAF's GLOW engine can expose an MCP server, so an agent can create projects, set fields and run transactions on the running solution. Use it to verify a change end to end. The `verify-with-mcp` skill has the steps. Keep `SOLUTION.md` short and specific: what the steps and fields mean, the order transactions must run in, and domain constraints.

## 10. Migrating an old project

1. Record first: tag the old project, save its package list, back up its data.
2. Create the SAF solution with `saf new` and apply this layer.
3. Move the entire old project into `legacy/` exactly as it is, in one commit that contains nothing else.
4. Move its data and heavy assets to `local/data/` and `local/assets/`, and register them with `just manifest-add`.
5. Give each legacy part an entity file with `status: legacy`.
6. Port one feature at a time into SAF steps with the `port-legacy-feature` skill. When a part is replaced, set `replaced_by` and delete it from `legacy/`.

Legacy is frozen: fixes only. Nothing new is added inside `legacy/`.

## 11. Checks that keep it working

| Check | How | When |
|---|---|---|
| Enforcement | Git hooks and the `Agent layer` workflow run `validate` and check branch and commit names | Every commit and pull request |
| Drift | `just scan --report` compares code with entity files | Every validate |
| Cold-start test | Give a fresh agent only `AGENTS.md` and ask it ten real questions | After setup and after big changes |
| Stale check | A scheduled agent re-verifies entity files and refreshes `last_verified` | Weekly |
| Backup check | `just validate --full` verifies manifest checksums | Weekly |
| Log compaction | `just compact` | Weekly |
