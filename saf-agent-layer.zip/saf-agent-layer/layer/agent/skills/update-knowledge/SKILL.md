---
name: update-knowledge
description: Use after changing code, to bring entity files, decisions and SOLUTION.md back in line with it.
---
# Update knowledge

1. Run `just scan`. It drafts entity files for new steps and pages and lists drift for existing ones.
2. For each entity file you touched or that drift names:
   - correct the fields, transactions, paths and `depends_on`;
   - add traps to "Gotchas";
   - set `updated_at`, and set `last_verified` only after checking the file against the code.
3. For things `scan` cannot see (services, products, data sets, external systems), run `just entity-new <id> <type>`.
4. If the design changed, run `just decision-new "<title>"` and fill in context, decision and consequences. Never edit an accepted decision; supersede it.
5. Update `SOLUTION.md` if steps, fields or the order of transactions changed.
6. Register new files under `local/data/`, `local/assets/` or `local/artifacts/` with `just manifest-add <path> --source "<where the master copy lives>"`.
7. Run `just validate` and fix every error.

Keep each entity file under 100 lines. Move long explanations to `agent/architecture/` and link to them.
