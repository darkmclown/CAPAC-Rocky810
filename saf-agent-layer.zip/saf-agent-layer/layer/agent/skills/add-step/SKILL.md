---
name: add-step
description: Use when the task needs a new workflow step in the solution.
---
# Add a step

1. Decide whether a new step is right: one step per logical concern. If the work belongs to an existing step, use `change-backend` instead.
2. Run `just templates` to list the step templates that are installed.
3. Run `just add-step <step-name> <template>`. Pass `none` as a third argument for a step without UI.
   - SAF scaffolds the step and adds its dependencies. The recipe then drafts the entity file.
4. Check that the step is registered in `definition.py`.
5. Fill in the step: fields, transactions, and the UI page if there is one.
6. Add tests, then run `just test`.
7. Complete the drafted entity file `agent/knowledge/entities/step-<name>.md` and set `last_verified`.
8. Add the step to the workflow in `SOLUTION.md`.
9. If the step changes the design of the workflow, run `just decision-new "<title>"` and record why.
