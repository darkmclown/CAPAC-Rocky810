---
name: finish-task
description: Use when the work is complete, to check it, write the run summary, close the task and open a pull request.
---
# Finish a task

1. Run `just check`. Fix failures; do not skip hooks.
2. Go through the task's acceptance checks one by one. For backend changes, use `verify-with-mcp`.
3. Apply the `update-knowledge` skill.
4. Fill in the run summary named by `just status`:
   - "What changed": the files and behaviour that changed;
   - "What failed": what you tried that did not work, or "nothing";
   - "Next": what the next run or the reviewer should do.
5. Commit your work: `<type>: <summary> [<task-id>]`.
6. Run `just task-done <id>`. It reruns the checks and validation, closes the run, moves the task to `done/` and commits that.
7. Push the branch and open a pull request with the template. List anything that needs human approval.

If the work is not finished, run `just run-end --status partial` instead, and write "Next" so the following run can continue.
