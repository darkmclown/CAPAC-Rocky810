---
name: verify-with-mcp
description: Use to verify a backend change end to end by driving the running solution through SAF's MCP server.
---
# Verify with the MCP server

## One-time setup

1. Add the `core-mcp` extra to the `ansys-saf-sdk` dependency, through `saf execute <solution> "poetry ..."`, then run `just setup`.
2. Set `GLOW_MCP_DISABLED=False` in `.env`.

## Each verification

1. Run `just run-api`. Wait for a log line saying MCP is mounted.
2. Connect your MCP client to the solution API URL plus the MCP path (default `/sse`).
3. Call `solution_workflow` to read the intended order of steps, and `saf_concepts` if you need SAF's terms.
4. Call `create_project` to get a fresh project. Never test on a user's project.
5. Set inputs with `set_fields`, then call the transaction tools. There is one tool per transaction method.
6. After a long-running transaction, call `wait_for_longrunning_transaction`.
7. Read results with `get_fields` and compare them with the task's acceptance checks.
8. Delete the test project with `delete_projects`.
9. Record the outcome: `just log mcp-verify --status ok` or `--status error --error "<what failed>"`.

Keep large files out of the MCP tools; their content passes through your context.

If the tool list or the workflow text no longer matches the code, update `SOLUTION.md`.
