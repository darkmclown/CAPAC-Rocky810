---
name: find-context
description: Use before opening source files, to locate the few files a task needs through the index instead of scanning the project.
---
# Find context

1. Run `just find <term>` with words from the task: a step name, a transaction, a field, a page.
2. Open the matching entity file in `agent/knowledge/entities/`. It names the code paths, the fields, the transactions and what depends on it.
3. Follow `depends on` and `used by` to see what your change can affect.
4. Check `agent/decisions/` for a record about this area before changing its design.
5. Open only the code paths the entity file lists. Use `rg` for anything the index does not cover.
6. If an entity file is missing or wrong, run `just scan` to draft it, then fix it as part of this task.

For how the running app is meant to be used, read `SOLUTION.md` beside `definition.py`.

Do not read `legacy/` unless the task or an entity file points there.
