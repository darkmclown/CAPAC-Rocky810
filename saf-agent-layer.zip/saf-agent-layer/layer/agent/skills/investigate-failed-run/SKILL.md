---
name: investigate-failed-run
description: Use when a run, a check or the solution itself failed and you need to find out why.
---
# Investigate a failed run

Read the cheapest source first.

1. The run summary: `agent/logs/<date>/<run-id>.md`, section "What failed".
2. The run events: `local/logs/<date>/<run-id>.jsonl`. Filter instead of reading it all:
   - `rg '"status":"error"' local/logs/<date>/<run-id>.jsonl`
   - across runs, with DuckDB: `SELECT run_id, tool, error FROM read_json('local/logs/*/*.jsonl') WHERE status = 'error' ORDER BY ts DESC LIMIT 20;`
3. The check output: run `just check` again and read the first failure, not the last.
4. The solution's own logs: run `just run --debug` and reproduce. SAF's debugging guide covers method logs, UI callback logs and telemetry.
5. The environment: if imports fail or tools are missing, run `saf install <solution> -d all -f`.

Then:

- write what you found under "What failed" in the current run summary;
- record it with `just log investigate --status ok --data cause="<short cause>"`;
- if the cause is a trap others will hit, add it to the "Gotchas" section of the entity file.
