---
name: manage-dependencies
description: Use when adding, removing or updating a Python dependency of the solution.
---
# Manage dependencies

SAF manages dependencies with Poetry, inside the solution environment.

1. Never edit `pyproject.toml` or `poetry.lock` by hand.
2. Run Poetry through SAF:
   - `saf execute <solution> "poetry add <package>"`
   - `saf execute <solution> "poetry add <package> --group <group>"`
   - `saf execute <solution> "poetry remove <package>"`
   - `saf execute <solution> "poetry lock"`
3. Reinstall with `just setup`. If the environment looks broken, run `saf install <solution> -d all -f`.
4. Run `just check`.
5. When several packages solve the same problem, tell the human about maintenance status and known security advisories so they can choose.
6. Record a new runtime dependency in the entity file of the step that uses it. Add a decision record if it is a significant choice.

Adding a dependency that needs a private package index or a license review needs human approval.
