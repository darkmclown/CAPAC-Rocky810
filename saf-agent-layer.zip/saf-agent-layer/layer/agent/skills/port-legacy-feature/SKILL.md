---
name: port-legacy-feature
description: Use when moving one feature from the old project in legacy/ into the SAF solution.
---
# Port a legacy feature

Port one feature per task. Legacy is frozen: read it, never extend it.

1. Find the legacy part's entity file (`status: legacy`) and read the code paths it lists under `legacy/`.
2. Write down what the feature does as inputs, outputs and rules. Put it in the task file under "Notes".
3. Capture current behaviour: run the old code on a few inputs and save the results as test expectations.
4. Map it to SAF:
   - inputs and outputs become step fields with defaults;
   - computations become plain functions, then `@transaction` methods;
   - files move through the step's storage scope;
   - screens become Dash pages that call the transactions.
5. Use `add-step` or `change-backend` to build it, with tests that reproduce the captured behaviour.
6. Data the feature needs goes to `local/data/` and into the manifest.
7. When the tests pass, set `replaced_by` on the legacy entity, then delete the replaced part from `legacy/`.
8. Record the mapping in a decision record if the design differs from the old one.

Deleting from `legacy/` and migrating data need human approval.
