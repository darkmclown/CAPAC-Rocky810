---
name: start-task
description: Use at the start of every run, before touching any file, to claim a task and open a run.
---
# Start a task

1. Read `AGENTS.md`, including the agent-layer section.
2. Run `just status` to see the branch and whether a run is already open.
3. Run `just task-list --remote` and pick a backlog task that nobody has claimed.
4. Read the task file. If the goal or the acceptance checks are unclear, stop and ask.
5. Make sure the working tree is clean and you are on the base branch, up to date.
6. Run `just task-claim <id> --type <feature|bugfix|hotfix|refactor> --agent <your-name>`.
   - If the claim is refused, another agent has the task. Pick a different one.
7. Continue with the `find-context` skill.

Resuming a task you already claimed: check out its branch and run `just run-start <id>`.

Never work on the base branch, and never work without an open run.
