---
name: change-ui
description: Use when changing Dash pages or UI assets of the solution.
---
# Change the UI

UI code lives under the solution's `ui/` folder: `app.py`, `pages/` and `assets/`. It talks to the backend through the GLOW API; it never holds business logic.

1. Find the page's entity file with `just find <page>` and read which step it serves.
2. Read SAF's frontend best practices before your first UI change. The rules it covers:
   - get the project through the required project-injection pattern;
   - use event listeners for long-running methods;
   - copy a dict field before modifying it;
   - prefer SAF's components before custom ones.
3. Make the change. Keep logic in the backend and call transactions from callbacks.
4. Update or add the UI test (see `tests/unit/test_solution_ui.py`), then run `just test`.
5. Check the result in the running app with `just run --browser`. Ask a human to look if you cannot see it.
6. Update the page's entity file.

Small assets stay in `ui/assets/`. A binary over about 1 MB goes to `local/assets/` and into the manifest.
