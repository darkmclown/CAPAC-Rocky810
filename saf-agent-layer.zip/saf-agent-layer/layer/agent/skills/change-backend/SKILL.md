---
name: change-backend
description: Use when changing a step's fields or transaction methods, or the solution definition, in the GLOW backend.
---
# Change the backend

Backend code lives under the solution's `solution/` folder: `definition.py` declares the steps, and each step module holds a `StepModel` class with fields and `@transaction` methods.

## Steps

1. Write or change the business logic as plain functions first, and test them on their own.
2. Wire the logic into the step:
   - add fields with type hints and default values;
   - add or change a `@transaction` method and declare what it downloads and uploads in its `StepSpec`;
   - use a long-running transaction for slow work.
3. Add or update tests in `tests/` using the solution's API fixtures. See `tests/unit/test_solution_api.py` for the pattern.
4. Run `just test`.
5. Run `just scan --report` and update the step's entity file and `SOLUTION.md` for anything it lists.

## Rules from SAF

- No code runs at import time. Put logic in methods and import heavy packages inside them.
- Every field has a default. No module-level globals. No session state in memory.
- One step per logical concern. Keep dependencies inside a step and declare cross-step reads explicitly.
- Never modify data that an entity handle refers to. Store a new entity instead.
- Read environment variables with `os.getenv` or Pydantic settings, never `load_dotenv()`.

Changing a field's type or removing a field can break saved projects. Treat it as a project migration and get human approval first.
