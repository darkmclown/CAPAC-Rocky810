---
run_id: {{run_id}}
task_id: {{task_id}}
agent: {{agent}}
started_at: {{now}}
ended_at: null
status: running        # running | success | failed | partial
---
## What changed

## What failed

## Next
