---
id: {{id}}
title: {{title}}
status: accepted       # proposed | accepted | superseded
created_at: {{now}}
supersedes: null
---
## Context

## Decision

## Consequences
