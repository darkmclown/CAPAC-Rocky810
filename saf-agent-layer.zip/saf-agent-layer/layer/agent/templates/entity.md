---
id: {{id}}
type: {{type}}
status: active         # active | legacy | deprecated
owner: unassigned
paths: []
depends_on: []
replaced_by: null
updated_at: {{now}}
last_verified: null
---
# {{id}}

What it is and what it is for, in two sentences.

## How it works

## Gotchas
