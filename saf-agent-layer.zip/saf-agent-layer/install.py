#!/usr/bin/env python3
"""Apply the agent layer to a SAF solution.

    python install.py <path-to-solution> [--force] [--any-project]

The installer only adds files and managed blocks. It never changes solution code,
and running it again updates the layer without touching your knowledge files.
Only the Python standard library is used.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

KIT = Path(__file__).resolve().parent
LAYER = KIT / "layer"
START, END = "agent-layer:start", "agent-layer:end"
EMPTY_DIRS = ["architecture", "decisions", "knowledge/entities", "tasks/backlog", "tasks/active", "tasks/done",
              "logs", "artifacts"]
LOCAL_DIRS = ["index", "logs", "run", "data", "assets", "artifacts"]


def detect(solution: Path) -> dict:
    """Read the solution name and source folder from SAF's own files."""
    info = {"is_saf": False, "solution_name": solution.name, "source_root": "src"}
    env = solution / ".env"
    match = re.search(r"^GLOW_SOLUTION_DEFINITION=(\S+)\.solution\.definition\s*$",
                      env.read_text(encoding="utf-8"), re.M) if env.is_file() else None
    if match:
        parts = match.group(1).split(".")
        info.update(is_saf=True, solution_name=parts[-1], source_root="src/" + "/".join(parts))
    pyproject = solution / "pyproject.toml"
    if pyproject.is_file() and "ansys-saf" in pyproject.read_text(encoding="utf-8"):
        info["is_saf"] = True
    return info


def replace_block(text: str, block: str, start: str, end: str) -> str:
    """Insert a managed block, or replace it when it is already there."""
    pattern = re.compile(rf"^[^\n]*{re.escape(start)}.*?{re.escape(end)}[^\n]*\n?", re.S | re.M)
    if pattern.search(text):
        return pattern.sub(lambda _: block, text, count=1)
    return text.rstrip("\n") + "\n\n" + block if text.strip() else block


def skills_list(solution: Path) -> str:
    lines = []
    for skill in sorted((solution / "agent" / "skills").glob("*/SKILL.md")):
        match = re.search(r"^description:\s*(.+)$", skill.read_text(encoding="utf-8"), re.M)
        lines.append(f"- `{skill.parent.name}`: {match.group(1).strip() if match else ''}")
    return "\n".join(lines)


def agents_block(solution: Path) -> str:
    return f"""<!-- {START} (managed by saf-agent-layer; change agent/ files, not this block) -->
## Agent layer

This project runs on the team platform: SAF hosts the application and the agent layer holds what agents need to work on it. [agent/standard.md](agent/standard.md) is the full reference.

### Every run

1. Read this file.
2. Run `just task-claim <id>`. It creates the task branch, opens a run and pushes the claim.
3. Load the skill that matches the task. Use `just find <term>` to locate the few files you need.
4. Do the work. Commit as `<type>: <summary> [<task-id>]`.
5. Run `just check` until it passes.
6. Update the entity files you touched, add a decision record if the design changed, and fill in the run summary.
7. Run `just task-done <id>`, then push and open a pull request.

Run `just --list` for every command. Without `just`, run `python agent/tools/agentkit.py --help`.

### Where things are

| Need | Where |
|---|---|
| Steps, transactions, UI pages, data sets | `agent/knowledge/entities/` |
| Why things are built this way | `agent/decisions/` |
| How parts work together | `agent/architecture/` |
| Work to do | `agent/tasks/backlog/` |
| What earlier runs did | `agent/logs/` |
| Data and heavy assets that exist | `local.manifest.jsonl` |
| How to drive the running solution | `SOLUTION.md` beside `definition.py` |
| Old project being ported | `legacy/`, only when a task points there |

### Rules

- Never commit `local/`. Secrets go in `local/secrets.env`, never in `.env`.
- Never work on the base branch, and never bypass git hooks.
- Change dependencies only through `saf execute`. Never edit `pyproject.toml` or `poetry.lock` by hand.
- Ask a human before anything irreversible: deploys, deletes, spending, and data or project migrations.
- Mark what you could not confirm as unverified. Never guess.
- Branch: `<feature|bugfix|hotfix|refactor>/T-0042-short-name`. Commit: `<type>: <summary> [T-0042]`.

### Skills

Load a skill from `agent/skills/<name>/SKILL.md` when its description matches the task.

{skills_list(solution)}
<!-- {END} -->
"""


def agents_template(info: dict, solution: Path) -> str:
    """The team template for AGENTS.md, with the managed section filled in."""
    text = (LAYER / "AGENTS.template.md").read_text(encoding="utf-8")
    text = text.replace("__SOLUTION__", info["solution_name"]).replace("__SOURCE_ROOT__", info["source_root"])
    return replace_block(text, agents_block(solution), START, END)


def copy_tree(source: Path, target: Path, overwrite: bool, report: list[str], base: Path) -> None:
    for path in sorted(p for p in source.rglob("*") if p.is_file() and "__pycache__" not in p.parts):
        destination = target / path.relative_to(source)
        if destination.exists() and not overwrite:
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        changed = not destination.exists() or destination.read_bytes() != path.read_bytes()
        shutil.copyfile(path, destination)
        if changed:
            report.append(f"wrote   {destination.relative_to(base).as_posix()}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Apply the agent layer to a SAF solution.")
    parser.add_argument("solution", type=Path, help="root folder of the solution (the one with pyproject.toml)")
    parser.add_argument("--force", action="store_true", help="also overwrite skills and templates you may have edited")
    parser.add_argument("--any-project", action="store_true", help="install even if this is not a SAF solution")
    parser.add_argument("--use-template", action="store_true",
                        help="replace AGENTS.md with the team template (it is used automatically when AGENTS.md is missing)")
    args = parser.parse_args()

    solution = args.solution.resolve()
    if not solution.is_dir():
        sys.exit(f"error: {solution} is not a folder")
    info = detect(solution)
    if not info["is_saf"] and not args.any_project:
        sys.exit("error: this does not look like a SAF solution (no GLOW_SOLUTION_DEFINITION in .env and no "
                 "ansys-saf dependency in pyproject.toml). Create one with `saf new`, or pass --any-project.")

    report: list[str] = []
    agent = solution / "agent"

    # 1. Tooling and the standard are managed files: always current.
    copy_tree(LAYER / "agent" / "tools", agent / "tools", True, report, solution)
    shutil.copyfile(LAYER / "agent" / "standard.md", agent / "standard.md")
    # 2. Skills and templates are yours to edit: only added when missing, unless --force.
    copy_tree(LAYER / "agent" / "skills", agent / "skills", args.force, report, solution)
    copy_tree(LAYER / "agent" / "templates", agent / "templates", args.force, report, solution)
    for name in EMPTY_DIRS:
        folder = agent / name
        folder.mkdir(parents=True, exist_ok=True)
        if not any(folder.iterdir()):
            (folder / ".gitkeep").touch()
    for name in LOCAL_DIRS:
        (solution / "local" / name).mkdir(parents=True, exist_ok=True)

    # 3. Settings.
    config = agent / "config.json"
    if not config.exists():
        config.write_text(json.dumps({
            "solution_name": info["solution_name"], "source_root": info["source_root"], "base_branch": "main",
            "check_command": ["just", "check"], "log_retention_days": 30,
        }, indent=2) + "\n", encoding="utf-8", newline="\n")
        report.append("wrote   agent/config.json")

    # 4. justfile.
    justfile = (LAYER / "justfile").read_text(encoding="utf-8").replace("__SOLUTION__", info["solution_name"])
    target = solution / "justfile"
    if target.exists() and "agent/tools/agentkit.py" not in target.read_text(encoding="utf-8"):
        target = solution / "justfile.agent-layer"
        report.append("note    you already have a justfile; wrote justfile.agent-layer for you to merge")
    target.write_text(justfile, encoding="utf-8", newline="\n")

    # 5. Manifest.
    manifest = solution / "local.manifest.jsonl"
    if not manifest.exists():
        manifest.touch()
        report.append("wrote   local.manifest.jsonl")

    # 6. AGENTS.md: keep SAF's text, add or refresh the managed section.
    agents = solution / "AGENTS.md"
    current = agents.read_text(encoding="utf-8") if agents.exists() else ""
    if args.use_template or not agents.exists():
        updated = agents_template(info, solution)
        note = "wrote   AGENTS.md from the team template. Replace every [fill in: ...] placeholder"
        if agents.exists():
            note += "; the previous text is in git history"
    else:
        updated = replace_block(current, agents_block(solution), START, END)
        note = "updated AGENTS.md (agent-layer section)"
    if updated != current:
        agents.write_text(updated, encoding="utf-8", newline="\n")
        report.append(note)

    # 7. .gitignore.
    gitignore = solution / ".gitignore"
    block = (LAYER / "gitignore-block.txt").read_text(encoding="utf-8")
    current = gitignore.read_text(encoding="utf-8") if gitignore.exists() else ""
    updated = replace_block(current, block, ">>> agent-layer >>>", "<<< agent-layer <<<")
    if updated != current:
        gitignore.write_text(updated, encoding="utf-8", newline="\n")
        report.append("updated .gitignore")

    # 8. pre-commit: append our hooks to the repos list when that is safe.
    precommit = solution / ".pre-commit-config.yaml"
    block = (LAYER / "precommit-block.yaml").read_text(encoding="utf-8")
    if precommit.exists():
        current = precommit.read_text(encoding="utf-8")
        top_keys = re.findall(r"^([A-Za-z_][\w-]*):", current, re.M)
        if ">>> agent-layer >>>" in current or (top_keys and top_keys[-1] == "repos"):
            updated = replace_block(current, block, ">>> agent-layer >>>", "<<< agent-layer <<<")
            if updated != current:
                precommit.write_text(updated, encoding="utf-8", newline="\n")
                report.append("updated .pre-commit-config.yaml (gitleaks, validation, commit message)")
        else:
            report.append("note    could not place hooks in .pre-commit-config.yaml automatically; "
                          f"copy them from {LAYER / 'precommit-block.yaml'}")
    else:
        precommit.write_text("repos:\n" + block, encoding="utf-8", newline="\n")
        report.append("wrote   .pre-commit-config.yaml")

    # 9. GitHub: workflow and pull request template.
    workflow = solution / ".github" / "workflows" / "agent-layer.yml"
    workflow.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(LAYER / "github" / "agent-layer.yml", workflow)
    template = solution / ".github" / "pull_request_template.md"
    if not template.exists():
        shutil.copyfile(LAYER / "github" / "pull_request_template.md", template)
        report.append("wrote   .github/pull_request_template.md")
    else:
        report.append("note    kept your existing pull request template")

    # 10. Draft knowledge from the source, build the index, validate.
    kit = [sys.executable, str(agent / "tools" / "agentkit.py")]
    for command in (["scan", "--solution-md"], ["index"], ["validate"]):
        result = subprocess.run(kit + command, cwd=solution, text=True, capture_output=True)
        report.append(f"ran     agentkit {' '.join(command)}: {(result.stdout.strip().splitlines() or ['no output'])[-1]}")
        if result.returncode != 0:
            report.append(result.stdout.strip())
            report.append(result.stderr.strip())

    print(f"Agent layer applied to {solution}")
    print(f"Solution name: {info['solution_name']}   source: {info['source_root']}")
    for line in report:
        if line:
            print("  " + line)
    print("""
Next steps
  1. Review the drafted files in agent/knowledge/entities/ and SOLUTION.md, then commit.
  2. Install the git hooks:  just hooks          (pre-commit, SAF's way)
                        or:  just hooks-native   (plain git hooks)
  3. Put secrets in local/secrets.env, never in .env.
  4. Create the first task:  just task-new "<title>"
""")


if __name__ == "__main__":
    main()
